
#!/bin/bash
#Loading the db2 profile
if [ -f /home/db2inst1/sqllib/db2profile ]; then
    . /home/db2inst1/sqllib/db2profile
fi
DB=<source database name>
USER=<local user name>
PASS=<local user password>
FROMTABLE=<source table name>
TOTABLE=<target table name>
SOURCESCHEMA=<source schema name>
TARGETSCHEMA=<target schema name>
db2 connect to $DB user $USER using $PASS
db2 "CREATE NICKNAME NN$SOURCESCHEMA.NN$FROMTABLE FOR DSNP.$TARGETSCHEMA.$FROMTABLE"
db2 "DECLARE C1 CURSOR FOR SELECT * FROM NN$SOURCESCHEMA.NN$FROMTABLE WITH UR"
db2 "LOAD FROM C1 OF CURSOR MESSAGES ./load.log REPLACE INTO $TARGETSCHEMA.$TOTABLE NONRECOVERABLE"
db2 "SET INTEGRITY FOR $TARGETSCHEMA.$FROMTABLE STAGING, MATERIALIZED QUERY, FOREIGN KEY, GENERATED COLUMN, CHECK IMMEDIATE UNCHECKED"
db2 "DROP NICKNAME NN$SOURCESCHEMA.NN$FROMTABLE"
db2 connect reset