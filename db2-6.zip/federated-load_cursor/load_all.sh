#!/bin/bash
#Loading the db2 profile
if [ -f /home/db2inst1/sqllib/db2profile ]; then
    . /home/db2inst1/sqllib/db2profile
fi
DB=<source database name>
USER=<local user name>
PASS=<local user password>
LOGFILE=<File for logging>
S_T=$SECONDS
echo Load of tables started 
db2 connect to $DB user $USER using $PASS > $LOGFILE
for TAB in <schema1.table1 schema2.table2 schema3.table3 ...> do
s_t=$SECONDS
echo $TAB load started
db2 -v "CREATE NICKNAME NN$ODSTAB FOR DSNP.$TAB" >> $LOGFILE
db2 -v "DECLARE C1 CURSOR FOR SELECT * FROM NN$TAB WITH UR" >> $LOGFILE
db2 -v "LOAD FROM C1 OF CURSOR MESSAGES ./$TAB.log REPLACE KEEPDICTIONARY INTO $TAB NONRECOVERABLE" >> $LOGFILE
db2 -v "SET INTEGRITY FOR $TAB STAGING, MATERIALIZED QUERY, FOREIGN KEY, GENERATED COLUMN, CHECK IMMEDIATE UNCHECKED" >> $LOGFILE
db2 -v "DROP NICKNAME NN$TAB" >> $LOGFILE
e_t=$(($SECONDS - $s_t))
echo $TAB load terminated - "$(($e_t/60)) min $(($e_t%60)) sec"
done
db2 connect reset >> $LOGFILE
E_T=$(($SECONDS - $S_T))
echo Load of tables terminated - "$(($E_T/60)) min $(($E_T%60)) sec"