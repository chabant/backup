#!/bin/bash


date

#-- validation of numbers of inputs
if [ $# -ne 1 ]
then
   echo "$?  <db2 name>=$1"
   exit 1
fi


#-- connect to the database
db2 -tv "connect to ${DB} "
if [ $? -ne 0 ]; then
   echo "ERROR connecting to ${DB}"
   exit 1
fi

db2 connect reset 


note :
******
db2 "select substr(replace(colnames,'+',','),2,length(colnames)) from syscat.indexes where trim(tabschema)||'.'||trim(tabname)='A5DREFER.A5TADRDIFFU' and UNIQUERULE ='P'"
INDX=$(db2 -x "select substr(replace(colnames,'+',','),2,length(colnames)) from syscat.indexes where trim(tabschema)||'.'||trim(tabname)='A5DREFER.A5TADRDIFFU' and UNIQUERULE ='P'")
echo $INDX
db2 -v "select * from A5DREFER.A5TADRDIFFU where ${INDX} not in (select ${INDX} from A5DREFER.A5TADRDIFFU )"

