#
########################################################################################################
#
#	Recherche des tables qui ont besoin d'etre "DB2" analysees (runstats).
#
#	Said FOURA	2009.03.05	creation.
#			2009.03.06	modification de la liste des schemas a exclure du runstats.
#			2009.03.12	correction de la commande sql.
#			2010.02.26	ajout option force pour analyser sans condition les tables
#
#######################################################################################################

#####################################################################
affiche_SYNTAXE()
{
 
echo -e "\n----> erreur syntaxe : ${0} DB2_ALIAS  [check OU analyze OU force]   NB_JOURS   SCHEMA_DB2 [ALL | NOSYS | \"'AAAAAA'[,'BBBBBBB'[,'CCCCCC'....]\"\n"
echo -e "check......: generation de la liste des commandes sql pour analyser les tables.\n"
echo -e "analyze....: generation / lancement des commandes sql pour analyser les tables.\n"
echo -e "force......: generation inconditionnelle de la liste des commandes sql pour analyser les tables.\n"
echo -e "NB_JOURS...: On veut analyser les tables dont les statistiques datent de NB_JOURS ou plus.\n\n"
echo -e "SCHEMA_DB2.: Si ce parametre est egal a \"'AAAAAA'\"........................alors on veut analyser ce schema uniquement.\n"
echo -e "...........: Si ce parametre est egal a \"'AAAAAA','BBBBBBB','CCCCCC'\".....alors on veut analyser ces schemas uniquement.\n"
echo -e "...........: Si ce parametre est egal a NOSYS.............................alors on veut analyser tous les schemas sauf les schemas SYSTEM.\n"
echo -e "...........: Si ce parametre est egal a  ALL..............................alors on veut analyser tous les schemas y compris les schemas SYSTEM.\n"

}
#
#	end of affiche_SYNTAXE
#####################################################################

check_SYNTAXE()
{

DB2_ALIAS="${1}"
OPTION="${2}"
NB_JOURS="${3}"
XX="${4}"
SCHEMA=""

if [ "${OPTION}" == "check" ] || [ "${OPTION}" == "analyze" ] || [ "${OPTION}" == "force" ]
then
	if [ "${XX}" == "ALL" ]
	then
		# ici on veut analyser TOUS les schemas DB2.
		SCHEMA=""
	elif [ "${XX}" == "NOSYS" ]
	then
		# ici on veut analyser tous les schemas DB2 sauf les schemas system
		SCHEMA=" and TABSCHEMA not in ('SYSCAT','SYSCATV82','SYSIBM','SYSSTAT','SYSTOOLS','SYSFUN','SQLJ','SYSPROC','NULLID','DB2XML','DB2GSE')"
	else
		# ATTENTION !!! ici  on est cense avoir recupere la liste de(s) schema(s) sous la forme  : soit un seul schema 'AAAAAAAA'
		# soit plusieurs schemas 'AAAAAAAA','BBBBBBB','CCCCCCCC'  etc ...

		SCHEMA=" and TABSCHEMA in (${XX})"
	fi
else
	return 1
fi

return 0

}
#
#	end of check_SYNTAXE
####################################################################

. $HOME/.profile

if [ $# -ne 4 ] || ! check_SYNTAXE $1 $2 $3 $4
then
	affiche_SYNTAXE
	exit $OK
fi

LHOST="`uname -n`"

MESG="*********************************************************************\n"
MESG=$MESG"`date` : lancement de ${0} ${DB2_ALIAS} ${OPTION} >= ${NB_JOURS} jour(s) ${SCHEMA}\n\n"

# !!!!!!!!! important
OK=0

if [ -d ${HOME}/admin/log ]
then
	DIRLOG="${HOME}/admin/log"
else
	DIRLOG="${HOME}"
fi

FICLOG="${DIRLOG}/`basename ${0} | cut -f1 -d.`_${DB2_ALIAS}_`date '+%d%m%G_%H%M'`.log"

TT=`db2 +o connect to ${DB2_ALIAS}`
if [ $? -eq 0 ]
then
	MESG=$MESG"`date` : Connexion a la base ${DB2_ALIAS} OK.\n"
else
	MESG=$MESG"----> `date` : !!!! Impossible de se connecter a la base DB2 ${DB2_ALIAS} !!!!\n"
	OK=`expr ${OK} + 1` 
fi


if [ $OK -eq 0 ]
then
	if [ -d ${HOME}/admin/log ]
	then
		DIRLOG="$HOME/admin/log"
	fi
	FICOUT="${DIRLOG}/`basename ${0} | cut -f1 -d.`_${OPTION}_${DB2_ALIAS}_`date '+%d%m%G_%H%M'`"

	#	ATTENTION  ${SCHEMA} est soit vide (on veut tout analuser) soit contient une liste de schemas a analyser. Voir plus haut dans check_SYNTAXE.

	##TIMESTAMPDIFF		2 Seconds 4 Minutes 8 Hours 16 Days 32 Weeks 64 Months 128 Quarters 256 Years

	# ${SCHEMA} est soit vide (on veut analyser tous les schemas)  soit est egal a " and TABSCHEMA in .......   Voir la syntaxe plus haut.
if [ "${OPTION}" == "force" ]
then
        db2 -x "select 'runstats on table '||rtrim(TABSCHEMA)||'.'||rtrim(TABNAME)||' on all columns with distribution on all columns and detailed indexes all allow write access;'||CHR(10)         \
from            SYSCAT.TABLES   \
where           TYPE = 'T' ${SCHEMA} order by NPAGES DESC" > ${FICOUT}.sql
	STATUS=$?
else
	db2 -x "select 'runstats on table '||rtrim(TABSCHEMA)||'.'||rtrim(TABNAME)||' on all columns with distribution on all columns and detailed indexes all allow write access;'||CHR(10)         \
from            SYSCAT.TABLES	\
where           TYPE = 'T' ${SCHEMA}	\
and             (STATS_TIME is null or TIMESTAMPDIFF(16,CHAR(CURRENT_TIMESTAMP - STATS_TIME)) > ${NB_JOURS})	\
order by        STATS_TIME" > ${FICOUT}.sql
	STATUS=$?
fi
	case $STATUS in
	0)
		MESG=$MESG"`date` : Des table(s) candidate(s) au  db2 RUNSTATS ont ete trouvee(s). Voir le fichier ${FICOUT}.sql\n"
		if [ "${OPTION}" == "analyze" ] || [ "${OPTION}" == "force" ]
		then
			if [ -s ${FICOUT}.sql ]
			then
				MESG=$MESG"`date` : lancement de db2 -stvf ${FICOUT}.sql -z ${FICOUT}.log\n"
				db2 -stvf ${FICOUT}.sql -z ${FICOUT}.log
				if [ $? -eq 0 ]
				then
					MESG=$MESG"`date` : db2 -stvf ${FICOUT}.sql -z ${FICOUT}.log bien termine.\n"
				else
					MESG=$MESG"----> `date` : !!!! Probleme lancement de db2 -stvf ${FICOUT}.sql -z ${FICOUT}.log !!!!\n"
					OK=`expr ${OK} + 1`
				fi
			else
				MESG=$MESG"----> `date` : !!!! Probleme generation du fichier des commandes sql pour analyser les tables. !!!\n"
				MESG=$MESG"----> Ce fichier ${FICOUT}.sql est vide ou n'existe pas. C'est peut-etre un probleme system (manque de place ...) !!!\n"
				OK=`expr ${OK} + 1`
			fi
		fi
	;;
	1)
		MESG=$MESG"`date` : Aucune table candidate au db2 RUNSTATS n'a ete trouvee.\n"
		# le fichier ${FICOUT}.sql cense contenir les commandes sql pour reorganiser les tables est vide. On fait le menage.
		rm -f ${FICOUT}.sql
	;;
	*)
		MESG=$MESG"----> `date` : !!!! Erreur lors de la generation de la liste des tables candidates au db2 RUNSTATS !!!!\n"
		OK=`expr ${OK} + 1`
	;;
	esac
	TT=`db2 +o terminate`
	if [ $? -eq 0 ]
	then
		MESG=$MESG"`date` : Deconnexion de la base DB2  ${DB2_ALIAS} OK.\n"
	else
		MESG=$MESG"----> `date` : !!!! Probleme lors de la deconnexion a la base DB2  ${DB2_ALIAS} !!!!\n"
		OK=`expr ${OK} + 1`
	fi	
fi

echo -e $MESG
echo -e $MESG > ${FICLOG}

if [ $OK -ne 0 ]
then
        echo -e $MESG | mailx -s "!!!!!! ${LHOST} : instance ${DB2INSTANCE} : lancement de ${0} ${DB2_ALIAS} ${OPTION} >= ${NB_JOURS} jour(s) ${SCHEMA}" assodba
fi

exit $OK
