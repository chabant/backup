#!/usr/bin/ksh 
#@(#)#===========================================================================#
#@(#)# Fichier  : ExecSQL.sh                                    	         #
#@(#)# Syntaxe  : ExecSQL.sh Userid Passwd Requete		 		 # 
#@(#)# Objet    : Ex�cute la requete SQL pass�e en param�tre, r�sultat -> fichier#
#@(#)# Projet   : AGFI / Pilotage R�assurance	                                 #
#@(#)# Auteur   : MANIEZ / QUIBEL                                                #
#@(#)# Histo.   :                                                                #
#@(#)#  Version | Date       | Auteur	|Modifications                           #
#@(#)#---------------------------------------------------------------------------#
#@(#)#  1.0     | xx/xx/2002 | QUIBEL	| Creation                               #
#@(#)#---------------------------------------------------------------------------#
#@(#)#  2.0     | 14/03/2003 | MANIEZ   | Ajout des param�tres Userid et Passwd  #
#@(#)#---------------------------------------------------------------------------#
#@(#)#  3.0     | 27/03/2003 | QUIBEL   | Gestion du mutlifichier r�sultat pour  #
#@(#)#          |            |          | �viter les contentions                 #
#@(#)#---------------------------------------------------------------------------#
#@(#)#  3.1     | 06/06/2003 | MANIEZ   | mont�e en production --> instance wfg  #
#@(#)#===========================================================================#

#=================  ***  ===================
# MAIN
#=================  ***  ===================
# Positionement dans le r�pertoire de stockage des shells
#cd /etlapp/WRDEV1/Scripts/
cd /etlapp/WRDEV1/Scripts
echo "##### ExecSQL.sh DEBUT #####" >> ExecSQLMulti.log

#-------------------------------------------------------
# ETAPE 1 : RECUPERATION DES PARAMETRES
#-------------------------------------------------------
echo "Param�tres : $*" >> ExecSQLMulti.log
# Identifiant de connexion
USERID=$1
# Mot de passe
PASSWD=$2
#Nom du fichier
FIC_RESULT=$3
# Ordre de connection
CONNECTION="connect to wr1pilot user ${USERID} using ${PASSWD}"

# Requ�te SQL : tous les param�tres � partir du 3�me
# (en fait cha�ne de caract�res s�par�s par de blancs)
for PARAM in $*
do
	if ( [ ${PARAM} != $1 ] && [ ${PARAM} != $2 ] && [ ${PARAM} != $3 ])
	then
		REQUETE="${REQUETE:-""} ${PARAM} "
	fi
done

#-------------------------------------------------------
# ETAPE 2 : EXECUTION DE LA REQUETE
#-------------------------------------------------------
# Nettoyage du fichier r�sultat
#rm ResExecSQL.log

# Chargement du profile DB2 ayant acc�s � l'instance DB2
#. /local/home/db2clt/sqllib/db2profile
#. /ClientGrpEtl_prd/home/db2clt/sqllib/db2profile
#./etl_infosphere_rec/home/db2inst1/sqllib/db2profile
. /home/db2luw1/sqllib/db2profile

# Connection � l'instance DB2
db2 ${CONNECTION} >> ExecSQLMulti.log

# Ex�cution de la requ�te
echo "Ordre ex�cut� : ${REQUETE}" >> ExecSQLMulti.log
db2 ${REQUETE} >> ${FIC_RESULT}

# Deconnection
db2 "connect reset" >> ExecSQLMulti.log
echo "##### ExecSQL.sh FIN #####" >> ExecSQLMulti.log
