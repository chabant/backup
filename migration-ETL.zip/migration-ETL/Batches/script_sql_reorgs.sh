#
########################################################################################################
#
#	Recherche des tables qui ont besoin d'etre "DB2" re-organisees (sauf les tables system).
#
#	Said FOURA	2009.03.05	creation.
#			2010.01.21	separation log du script et log sql
#			2010.02.26	ajout option force
#			2013.10.17	On ne lance la "reorgs" que si la fragmentation depasse 5 % ( FPAGES / NPAGES )
#
#######################################################################################################

#####################################################################
check_SYNTAXE()
{
	echo -e "\n----> erreur syntaxe : ${0} DB2_ALIAS check | reorg | force\n"
	echo -e "check..: generation de la liste des commandes sql pour reorganiser les tables.\n"
	echo -e "reorg..: generation / lancement des commandes sql pour reorganiser les tables.\n\n"
}
#
#	end of check_SYNTAXE
####################################################################

. $HOME/.profile

if [ $# -ne 2 ]
then
	check_SYNTAXE
	exit 1
fi

DB2_ALIAS="${1}"
OPTION="${2}"

if [ "${OPTION}" != "check" ] && [ "${OPTION}" != "reorg" ] && [ "${OPTION}" != "force" ]
then
	check_SYNTAXE
	exit 1
fi

LHOST="`uname -n`"

MESG="*********************************************************************\n"
MESG=$MESG"`date` : lancement de ${0} ${DB2_ALIAS} ${OPTION}\n\n"

# !!! important
OK=0

DIRLOG="${HOME}"
if [ -d ${HOME}/admin/log ]
then
	DIRLOG="$HOME/admin/log"
fi

TT=`db2 +o connect to ${DB2_ALIAS}`
if [ $? -eq 0 ]
then
	MESG=$MESG"`date` : Connexion a la base ${DB2_ALIAS} OK.\n"
else
	MESG=$MESG"----> `date` : !!!! Impossible de se connecter a la base DB2 ${DB2_ALIAS} !!!!\n"
	OK=`expr ${OK} + 1` 
fi

FICLOG="${DIRLOG}/`basename ${0} | cut -f1 -d.`_${DB2_ALIAS}_`date '+%d%m%G_%H%M'`.log"

if [ $OK -eq 0 ]
then
	FICOUT="${DIRLOG}/`basename ${0} | cut -f1 -d.`_${OPTION}_${DB2_ALIAS}_`date '+%d%m%G_%H%M'`"

	if [ "${OPTION}" == "force" ]
	then
db2 -xn "select 'REORG TABLE '||rtrim(TTAB.TABSCHEMA)||'.'||rtrim(TTAB.TABNAME)||' allow read access;'||CHR(10)||         \
'REORG INDEXES ALL FOR TABLE '||rtrim(TIND.TABSCHEMA)||'.'||rtrim(TIND.TABNAME)||';'||CHR(10)||   \
'RUNSTATS ON TABLE '||rtrim(TTAB.TABSCHEMA)||'.'||rtrim(TTAB.TABNAME)||' on all columns with distribution on all columns and detailed indexes all allow write access;'    \
from            SYSCAT.TABLES  TTAB,  SYSCAT.INDEXES TIND \
where           TTAB.TABSCHEMA not in ('SYSCAT','SYSCATV82','SYSIBM','SYSSTAT','SYSTOOLS','SYSFUN','SQLJ','SYSPROC','NULLID')   \
and             TTAB.TYPE = 'T'      \
and             TTAB.TABSCHEMA = TIND.TABSCHEMA \
and             TTAB.TABNAME   = TIND.TABNAME   \
and             TTAB.FPAGES > 0      \
order by        TTAB.NPAGES desc for read only" > ${FICOUT}.sql
	        STATUS=$?
	else
db2 -xn "select 'REORG TABLE '||rtrim(TTAB.TABSCHEMA)||'.'||rtrim(TTAB.TABNAME)||' allow read access;'||CHR(10)||         \
'REORG INDEXES ALL FOR TABLE '||rtrim(TIND.TABSCHEMA)||'.'||rtrim(TIND.TABNAME)||';'||CHR(10)||   \
'RUNSTATS ON TABLE '||rtrim(TTAB.TABSCHEMA)||'.'||rtrim(TTAB.TABNAME)||' on all columns with distribution on all columns and detailed indexes all allow write access;'    \
from            SYSCAT.TABLES  TTAB,  SYSCAT.INDEXES TIND \
where           TTAB.TABSCHEMA not in ('SYSCAT','SYSCATV82','SYSIBM','SYSSTAT','SYSTOOLS','SYSFUN','SQLJ','SYSPROC','NULLID')   \
and             TTAB.TYPE = 'T'      \
and             TTAB.TABSCHEMA = TIND.TABSCHEMA \
and             TTAB.TABNAME   = TIND.TABNAME   \
and             TTAB.FPAGES > 0      \
and             (FLOAT(TTAB.FPAGES) - FLOAT(TTAB.NPAGES))/(FLOAT(TTAB.FPAGES)) > 0.05 \
order by        TTAB.NPAGES desc for read only" > ${FICOUT}.sql
		STATUS=$?
	fi
	case $STATUS in
	0)
		MESG=$MESG"`date` : Des table(s) candidate(s) au  db2 reorg ont ete trouvee(s). Voir le fichier ${FICOUT}.sql\n"
		if [ "${OPTION}" == "reorg" ] || [ "${OPTION}" == "force" ]
		then
			if [ -s ${FICOUT}.sql ]
			then
				MESG=$MESG"`date` : lancement de db2 -tvf ${FICOUT}.sql -z ${FICOUT}.log\n"
				db2 -tvf ${FICOUT}.sql -z ${FICOUT}.log
				if [ $? -eq 0 ]
				then
					MESG=$MESG"`date` : lancement de db2 -tvf ${FICOUT}.sql -z ${FICOUT}.log bein termine.\n"
				else
					MESG=$MESG"----> `date` : !!!! Probleme lancement de db2 -tvf ${FICOUT}.sql -z ${FICOUT}.log !!!!\n"
					OK=`expr ${OK} + 1`
				fi
			else
				MESG=$MESG"----> `date` : !!!! Probleme generation du fichier des commandes sql pour reorganiser les tables. !!!\n"
				MESG=$MESG"----> Ce fichier ${FICOUT}.sql est vide ou n'existe pas. C'est peut-etre un probleme system (manque de place ...) !!!\n"
				OK=`expr ${OK} + 1`
			fi
		fi
	;;
	1)
		MESG=$MESG"`date` : Aucune table candidate au db2 reorg n'a ete trouvee.\n"
		# le fichier ${FICOUT}.sql cense contenir les commandes sql pour reorganiser les tables est vide. On fait le menage.
		rm -f ${FICOUT}.sql
	;;
	*)
		MESG=$MESG"----> `date` : !!!! Erreur lors de la generation de la liste des tables candidates au db2 reorg !!!!\n"
		OK=`expr ${OK} + 1`
	;;
	esac
	TT=`db2 +o terminate`
	if [ $? -eq 0 ]
	then
		MESG=$MESG"`date` : Deconnexion de la base DB2  ${DB2_ALIAS} OK.\n"
	else
		MESG=$MESG"----> `date` : !!!! Probleme lors de la deconnexion a la base DB2  ${DB2_ALIAS} !!!!\n"
		OK=`expr ${OK} + 1`
	fi	
fi

echo -e $MESG > $FICLOG
echo -e $MESG

if [ $OK -ne 0 ]
then
        echo -e $MESG | mailx -s "!!!!!! ${LHOST} : instance ${DB2INSTANCE} : lancement de ${0} ${DB2_ALIAS} ${OPTION}" assodba
fi

exit $OK
