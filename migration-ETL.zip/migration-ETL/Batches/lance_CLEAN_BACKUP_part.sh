#!/bin/ksh
##########################################################################
#
#	Said Foura 2012.01.27	creation
#
#	Pour DB2 partitionne sur des serveurs "physiques" ( qs03622 / qs03623 )   (qs03518 / qs03519 ) ou meme pourquoi pas sur un serveur "logique"
#
#	Ici les donnees sont simples : le jours J
#		on "vide" le repertoire   \$DB2_DIR_BACKUP/old		                            servira pour la sauvegarde temporaire J - 2
#		on deplace les backups de \$DB2_DIR_BACKUP/archive vers \$DB2_DIR_BACKUP/old	    sauvegarde J - 2
#		on deplace les backups de \$DB2_DIR_BACKUP          vers \$DB2_DIR_BACKUP/archive  sauvegarde J - 1
#	
#		la sauvegarde J - 2 doit etre efface a la BONNE FIN de la sauvegarde J sinon 
#
#		En principe on doit avoir un seul "jeu" de backup dans chacun des 2 repertoires
#		la sauvegarde du jour dans      \$DB2_DIR_BACKUP		sauvegarde J
#		la sauvegarde de la veille dans \$DB2_DIR_BACKUP/archive	sauvegarde J - 1
#
#	17.01.2013	Consolidation du script.
#	18.01.2013	Test Cluster afin de mieux utiliser les commandes unix du type  mv ( sur un seul node afin d'eviter code retour erreur )
#	06.08.2013	Consolidation gestion des sauvegardes.
#	19.08.2013	on enleve l'option -B du ping .. ( non reconnue sous aix .. )
#
##########################################################################

###################################################################################

affiche_SYNTAXE()
{

echo -e "\n"
echo -e "syntaxe........: ${0} DB2_ALIAS DB2_DIR_BACKUP [check | clean | raze]\n"
echo -e "DB2_ALIAS......: nom de la base.\n"
echo -e "DB2_DIR_BACKUP.: repertoire de sauvegarde (NE DOIT PAS SE TERMINER AVEC / !!!!!). ET DOIT CONTENIR LES SOUS-REPERTOIRES archive et old  .\n"
echo -e "...............: ATTENTION : le chemin du repertoire de BACKUP doit etre identique sur tous les serveurs !!!!\n"
echo -e "...............: \n"
echo -e "check..........: On verifie l'existence (et le contenu) des repertoires suivants : \n\n"
echo -e "...............: DB2_DIR_BACKUP           DB2_DIR_BACKUP/archive         DB2_DIR_BACKUP/old.\n"
echo -e "...............: \n"
echo -e "clean..........: on deplace les fichiers de DB2_DIR_BACKUP/archive (s'il contient des fichiers) vers DB2_DIR_BACKUP/old\n"
echo -e "...............: on deplace les fichiers de DB2_DIR_BACKUP          (s'ils existent)             vers DB2_DIR_BACKUP/archive.\n"
echo -e "...............: \n"
echo -e "raze...........: on vide le repertoire DB2_DIR_BACKUP/old.\n\n"

}
#	end of affiche_SYNTAXE
###################################################################################

check_SYNTAXE()
{

DB2_ALIAS=$1
DB2_DIR_BACKUP=$2
OPTION=$3

if [ "${OPTION}" != "check" ] && [ "${OPTION}" != "clean" ] && [ "${OPTION}" != "raze" ]
then
	return 1
fi

return 0

}
#	end of check_SYNTAXE
#--------------------------------------------------------------------------------

check_ONLINE_SERVEURS()
{

X_Server="${1}"

#TT="`ping -B -c 3 -q ${X_Server}`"
TT="`ping -c 3 -q ${X_Server}`"
if [ $? -eq 0 ]
then
	MESG=$MESG"\n""----> `date` : Le serveur ${X_Server} repond bien au ping.\n"
else
	MESG=$MESG"----> !!!! `date` : check_ONLINE_SERVEURS:: Le serveur ${X_Server} ne repond pas au ping !!!!\n"
	MESG=$MESG"----------------------------------------------------------------------------------\n\n"
	MESG=$MESG${TT}"\n\n"
	OK=`expr $OK + 1`
fi

return $OK

}
#	check_ONLINE_SERVEURS
#---------------------------------------------------------------------------------

check_PART_SERVEURS()
{

#
#	ici on recupere la liste (et le nombre) de serveurs ou "tourne" db2 pertitionne. On en a besoin pour etre sur
#	que toutes les commandes sont bien executees sur TOUS les serveurs.
#

CESERVEUR=`uname -n`
if [ $? -eq 0 ] && [ -n "${CESERVEUR}" ]
then
	NB_SERVEURS=0
	LOCAL_HOST="`cat $HOME/sqllib/db2nodes.cfg | awk '{print $2}' | grep ${CESERVEUR} | uniq`"
	if [ $? -eq 0 ] && [ -n "${LOCAL_HOST}" ]
	then
		MESG=${MESG}"\n""----> `date` : on a un serveur (local) ${LOCAL_HOST}.On va essayer de le "pinger" ....\n"
		if check_ONLINE_SERVEURS ${LOCAL_HOST}
		then
			NB_SERVEURS=1
			
			NB_RHOSTS=`cat $HOME/sqllib/db2nodes.cfg | awk '{print $2}' | grep -v ${LOCAL_HOST} | uniq | wc -l`
			if [ $? -eq 0 ]
			then
				if [ $NB_RHOSTS -gt 0 ]
				then
					LISTE_RHOSTS="`cat $HOME/sqllib/db2nodes.cfg | awk '{print $2}' | grep -v ${LOCAL_HOST} | uniq`"
					if [ $? -eq 0 ] && [ -n "${LISTE_RHOSTS}" ]
					then
						MESG=${MESG}"\n""----> `date` : On a le(s) serveur(s) distant(s) suivant(s) : ${LISTE_RHOSTS}.On va essayer de les "pinger" ....\n"
						NB_RHOSTS=0
						for REMOTE_HOST in `echo ${LISTE_RHOSTS}`
						do
							if [ $? -eq 0 ] && [ -n "${REMOTE_HOST}" ]
							then
								if check_ONLINE_SERVEURS ${REMOTE_HOST}
								then
									NB_RHOSTS=`expr ${NB_RHOSTS} + 1`
								fi	
							else
								MESG=$MESG"----> !!!! `date` : check_PART_SERVEURS:: PROBLEME determination variable REMOTE_HOST = ${REMOTE_HOST} !!!!\n"
								OK=`expr $OK + 1`
							fi
						done
						if [ $OK -eq 0 ]
						then
							NB_SERVEURS=`expr ${NB_SERVEURS} + ${NB_RHOSTS}`
							MESG=${MESG}"\n""----> `date` : On a ${NB_SERVEURS} serveurs : 1 serveur local et ${NB_RHOSTS} serveur(s) distant(s).\n"
						fi
					else
						MESG=$MESG"----> !!!! `date` : check_PART_SERVEURS:: PROBLEME determination liste des serveurs remotes LISTE_RHOSTS = ${LISTE_RHOSTS} !!!!\n\n"
						OK=`expr $OK + 1`
					fi
				fi
			else
				MESG=$MESG"----> !!!! `date` : check_PART_SERVEURS:: PROBLEME determination nombre serveurs distants NB_RHOSTS = ${NB_RHOSTS} !!!!\n\n"
				OK=`expr $OK + 1`
			fi
		fi
	else
		MESG=$MESG"----> !!!! `date` : check_PART_SERVEURS:: PROBLEME determination variable LOCAL_HOST = ${LOCAL_HOST}  !!!!\n"
		OK=`expr $OK + 1`
	fi
else
	MESG=$MESG"----> !!!! `date` : check_PART_SERVEURS:: PROBLEME determination du serveur local CESERVEUR = ${CESERVEUR}  !!!!\n\n"
	OK=`expr $OK + 1`
fi

return $OK

}
#	check_PART_SERVEURS
#--------------------------------------------------------------------------------

#
#	Si on est en mode "cluster storage" (ou partage NFS) (disques visibles et utilisables sur TOUS les nodes la commande "rah" couplee avec les commandes unix "mv" "rm" etc ...
#	va poser probleme .... si on deplace les backups vers le sous-repertoire archive sur le node 0 on ne peut plus le faire sur les autres nodes (c'est deja fait) etc etc ..
#
#	Dans ce cas on se contente de faire le travail sur un seul node ...
#
#	Bref 
#


IS_This_A_CLUSTER_Storage()
{

HH=0
FICHIER_TEST=".TEST_CLUSTER_Storage_$$"

TT=`RAHOSTLIST="${LOCAL_HOST}" rah "touch ${DB2_DIR_BACKUP}/${FICHIER_TEST}" | grep -i "completed ok"`
if [ $? -eq 0 ]
then
	MESG=$MESG"\n""`date` : IS_This_A_CLUSTER_Storage:: le serveur local ${LOCAL_HOST} semble faire partie du CLUSTER_Storage.\n"
	for RRHOST in `echo ${LISTE_RHOSTS}`
	do
		TT=`RAHOSTLIST="${RRHOST}" rah "ls -ltr ${DB2_DIR_BACKUP}/${FICHIER_TEST}" | grep -i "completed ok"`
		if [ $? -eq 0 ]
		then
			MESG=$MESGi"\n""`date` : IS_This_A_CLUSTER_Storage:: le serveur distant ${RRHOST} semble faire partie du CLUSTER_Storage.\n"
		else
			MESG=$MESG"----> !!!! `date` : IS_This_A_CLUSTER_Storage:: le serveur distant ${RRHOST} ne semble pas faire partie du CLUSTER_Storage ..!!!!\n"
			HH=`expr ${HH} + 1`
		fi
	done
else
	MESG=$MESG"----> !!!! `date` : IS_This_A_CLUSTER_Storage:: le serveur local ${LOCAL_HOST} ne semble pas faire partie du CLUSTER_Storage ..!!!!\n"
	HH=`expr ${HH} + 1`
fi

return $HH

}
#	IS_This_A_CLUSTER_Storage
#--------------------------------------------------------------------------------

#--------------------------------------------------------------------------------

#       rah "ls /DB2_LOCAL_FS/db2ese95/DBESE95/DBESE95.*"

#       /DBESE95.0.db2ese95.NODE0000.CATN0000.20120127113706.001
#       /DBESE95.0.db2ese95.NODE0002.CATN0000.20120127113715.001
#       cirta87: ls /DB2_LOCAL_FS/db2ese95/DBESE95/DBESE95.* completed ok
  
#       DBESE95.0.db2ese95.NODE0001.CATN0000.20120127113715.001
#       DBESE95.0.db2ese95.NODE0003.CATN0000.20120127113720.001
#       milev87: ls /DB2_LOCAL_FS/db2ese95/DBESE95/DBESE95.* completed ok
#       echo $?
#       0
#       rah "ls /DB2_LOCAL_FS/db2ese95/DBESE95/archive/DBESE95.*"

#       ls: cannot access /DB2_LOCAL_FS/db2ese95/DBESE95/archive/DBESE95.*: No such file or directory
#       cirta87: ls /DB2_LOCAL_FS/db2ese95/DBESE95/archive/DBESE95.* completed rc=2

#       ls: cannot access /DB2_LOCAL_FS/db2ese95/DBESE95/archive/DBESE95.*: No such file or directory
#       milev87: ls /DB2_LOCAL_FS/db2ese95/DBESE95/archive/DBESE95.* completed rc=2
#       echo $?
#       0

###################################################################################

check_DIR_BACKUPS()
{

REPERTOIRE=$1

NB_STATUS_OK=`rah "[ -d ${REPERTOIRE} ]" | grep "completed ok" | wc -l`
if [ $? -eq 0 ] && [ -n "${NB_STATUS_OK}" ]
then
	if [ ${NB_STATUS_OK} -eq ${NB_SERVEURS} ]
	then
		MESG=${MESG}"\n""----> `date` : le repertoire ${REPERTOIRE} existe sur les ${NB_SERVEURS} serveurs.On continue.\n"
	else
		MESG=${MESG}"----> !!!! `date` : check_DIR_BACKUPS:: PROBLEME le repertoire ${REPERTOIRE} n'existe pas sur au moins 1 des ${NB_SERVEURS} serveurs !!!!\n\n"
		OK=`expr ${OK} + 1`
	fi
else
	MESG=${MESG}"----> !!!! `date` : check_DIR_BACKUPS:: PROBLEME avec la commande DB2 ESE : rah [ -d ${REPERTOIRE} ] | grep "completed ok" | wc -l !!!!\n\n"
	OK=`expr ${OK} + 1`
fi

return $OK

}
#	end of check_DIR_BACKUPS
#--------------------------------------------------------------------------------

content_empty_DIR_BACKUPS()
{

#
# ATTENTION !! ici on ne "perturbe" pas la variable "globale" OK car quelque soit le resultat on s'en "contente" fichiers ou pas fichiers.
#
#
REPERTOIRE=$1

# on suppose que le repertoire REPERTOIRE est vide sur TOUS les serveurs.
TT=0

RETOUR=`rah "ls ${REPERTOIRE}/${DB2_ALIAS}.*" | grep "completed ok"`
if [ $? -eq 0 ]
then
	NB_STATUS_OK=`rah "ls ${REPERTOIRE}/${DB2_ALIAS}.*" | grep "completed ok" | wc -l`
	if [ ${NB_STATUS_OK} -eq ${NB_SERVEURS} ]
	then
		MESG=${MESG}"\n""----> `date` : le repertoire ${REPERTOIRE} n'est pas vide sur TOUS les (${NB_SERVEURS}) serveurs.\n"
	else
		MESG=${MESG}"\n""----> `date` : le repertoire ${REPERTOIRE} n'est pas vide sur au moins 1 des ${NB_SERVEURS} serveurs.\n"
	fi
	MESG=${MESG}"---------------------------------------------------------------------------------------------\n\n"
	MESG=${MESG}${RETOUR}"\n\n"

	TT=1
else
	MESG=${MESG}"\n""----> `date` : le repertoire ${REPERTOIRE} est vide sur TOUS les ${NB_SERVEURS} serveurs.\n"
fi

return $TT

}
#       end of content_empty_DIR_BACKUPS
#--------------------------------------------------------------------------------

delete_content_DIR_BACKUPS()
{

REPERTOIRE=$1

NB_STATUS_OK=`rah "rm -f ${REPERTOIRE}/${DB2_ALIAS}.*" | grep "completed ok" | wc -l`
if [ $? -eq 0 ] && [ -n "${NB_STATUS_OK}" ]
then
	if [ ${NB_STATUS_OK} -eq ${NB_SERVEURS} ]
	then
		MESG=${MESG}"----> `date` : rm -f ${REPERTOIRE}/${DB2_ALIAS}.* OK sur TOUS les (${NB_SERVEURS}) serveurs.\n\n"
	else
		MESG=${MESG}"----> !!!! `date` : delete_content_DIR_BACKUPS:: PROBLEME avec la commande : rm -f ${REPERTOIRE}/${DB2_ALIAS}.* sur au moins un serveur  !!!!\n\n"
		OK=`expr ${OK} + 1`
	fi
else
	MESG=${MESG}"----> !!!! `date` : delete_content_DIR_BACKUPS:: PROBLEME avec la commande : rah rm -f ${REPERTOIRE}/${DB2_ALIAS}.* | grep \"completed ok\" !!!!\n\n"
	OK=`expr ${OK} + 1`
fi

return $OK

}
#	end of delete_content_DIR_BACKUPS
#----------------------------------------------------------------------------------

move_content_ARCH_BACKUPS()
{

DIR_1=$1
DIR_2=$2

 # si on a affaire a un cluster les commandes unix du type mv ne seront executees que sur le node local sinon elles le seront sur chacun des nodes.

if IS_This_A_CLUSTER_Storage
then
	MV_STATUS=`RAHOSTLIST="${LOCAL_HOST}" rah "mv ${DIR_1}/${DB2_ALIAS}.*  ${DIR_2}"  | grep "completed ok"`
	TT=$?
else
	MV_STATUS=`rah "mv ${DIR_1}/${DB2_ALIAS}.*  ${DIR_2}"  | grep "completed ok"`
	TT=$?
fi

if [ $TT -eq 0 ]
then
	MESG=${MESG}"----> `date` : mv ${DIR_1}/${DB2_ALIAS}.* ${DIR_2} OK sur TOUS les (${NB_SERVEURS}) serveurs.\n\n"
else
	MESG=${MESG}"----> !!!! `date` : move_content_ARCH_BACKUPS:: PROBLEME commande : rah mv ${DIR_1}/${DB2_ALIAS}.* ${DIR_2} sur au moins un des ${NB_SERVEURS} serveurs !!!!\n\n"
	MESG=${MESG}"************************************************************************************\n\n"
	MESG=${MESG}${MV_STATUS}"\n\n"

	OK=`expr ${OK} + 1`
fi
 
return $OK

}
#	end of move_content_ARCH_BACKUPS
###################################################################################

if [ $# -ne 3 ] || ! check_SYNTAXE $1 $2 $3
then
	affiche_SYNTAXE
	exit 1
fi

. $HOME/.profile

if [ -d ${HOME}/admin/log ]
then
	DIRLOG="${HOME}/admin/log"
else
	DIRLOG="${HOME}"
fi

FICLOG="${DIRLOG}/`basename ${0} | cut -f1 -d.`_${DB2_ALIAS}_`date '+%d%m%G_%H%M'`.log"

LEHOST="`uname -n`"

MESG="*************************************************************************\n"
MESG=$MESG"`date` : ${LEHOST} : lancement de ${0} ${DB2_ALIAS} ${DB2_DIR_BACKUP} ${OPTION}.\n\n"

# !!! IMPORTANT
OK=0

if check_PART_SERVEURS
then
	if check_DIR_BACKUPS ${DB2_DIR_BACKUP} && check_DIR_BACKUPS ${DB2_DIR_BACKUP}/archive && check_DIR_BACKUPS ${DB2_DIR_BACKUP}/old
	then

		if [ "${OPTION}" == "check" ]
		then
			content_empty_DIR_BACKUPS ${DB2_DIR_BACKUP}
			content_empty_DIR_BACKUPS ${DB2_DIR_BACKUP}/archive
			content_empty_DIR_BACKUPS ${DB2_DIR_BACKUP}/old

		elif [ "${OPTION}" == "raze" ]
		then
			if ! content_empty_DIR_BACKUPS ${DB2_DIR_BACKUP}/old
			then
				delete_content_DIR_BACKUPS ${DB2_DIR_BACKUP}/old
			fi
		else
			# si le repertoire DB2_DIR_BACKUP contient quelque chose, on doit le deplacer dans DB2_DIR_BACKUP/archive
			if ! content_empty_DIR_BACKUPS ${DB2_DIR_BACKUP}
			then
				# si le repertoire DB2_DIR_BACKUP/archive contient quelque chose, on doit le deplacer dans DB2_DIR_BACKUP/old
				if ! content_empty_DIR_BACKUPS ${DB2_DIR_BACKUP}/archive
				then
					move_content_ARCH_BACKUPS  ${DB2_DIR_BACKUP}/archive ${DB2_DIR_BACKUP}/old
				fi
				move_content_ARCH_BACKUPS  ${DB2_DIR_BACKUP} ${DB2_DIR_BACKUP}/archive
			fi
		fi
	fi
fi

echo -e $MESG
echo -e $MESG > ${FICLOG}

if [ $OK -ne 0 ]
then
	echo -e $MESG | mailx -s "${LEHOST} !!!!!!!!!!! : lancement de ${0} ${DB2_ALIAS} ${DB2_DIR_BACKUP} ${OPTION}" assodba
fi

exit $OK

