#!/bin/sh
#


DBCIBLE=${1}



date

#-- validation of numbers of inputs
if [ $# -ne 1 ]
then
   echo "$?  <Database Name>=$1 "
   exit 1
fi


#-- connection to db
db2 -v connect to ${DBCIBLE}


TABLES=$(db2 -x "SELECT trim(tabschema)||'.'||trim(tabname) 
				FROM SYSCAT.TABLES 
				WHERE TABSCHEMA NOT LIKE 'SYS%' 
					AND TYPE IN ('T','U') 
					AND TABNAME not like '%EXPLAIN_%' 
					AND (TABSCHEMA,TABNAME) IN (
						SELECT b.creator,a.tbname
						FROM SYSIBM.SYSCOLUMNS as a,SYSIBM.SYSTABLES as b  
						WHERE  b.creator NOT LIKE 'SYS%' 
							and a.COLTYPE in ('LONG VARCHAR','LOB','BLOB','CLOB') 
							and a.tbname=b.name 
							and b.TYPE='T' )")		


for tbl in ${TABLES}
 do
    echo ${tbl}
	NICKNAME=`echo ${tbl} |cut -d . -f 2 ` 
	echo ${NICKNAME}
    db2 -v "DECLARE C1 CURSOR FOR Select * from SRC.${NICKNAME} with UR"
    db2 -v "LOAD FROM C1 OF CURSOR replace INTO ${tbl} nonrecoverable data buffer 30000 cpu_parallelism 4 ";
    db2 -v "Close  C1";
done
db2 CONNECT RESET;
db2 TERMINATE;
date;

