readme_DPF.txt: Migration DB2 AIX 

OBJET: Mode d'emploi des scripts de migration des bases DB2 AIX DPF  8.2 => 11.1

Modifications V1.31:
--------------------
- db2rbind maintenant avec option any pour tous les scripts apres restauration des bases (9.7 et 11.1)
- backup 11.1: Nouveau parametre dans fichier prestix11.properties.
					Apr�s restauration base 11.1, possibilite de faire un backup en renseignant la variable: DBCK11
					si la variable n'est pas renseignee, pas de backup 
					si un repertoire est indique mais n'existe pas, arret du shell en erreur avant migration
					su un repertoire est indique et existe, backup de la base 11 a la fin de la migration.

0 - Introduction:
=================
La migration se fait en 3 temps:

0.1 => sur le serveur 8.2: Backup (une ou plusieurs) base(s) DPF (ou non)
		Le principe est une migration "par lot": on peut migrer une/plusieurs base(s) pour une instance donn�e

0.2 => sur le serveur 9.7:
		- restore direct (depuis 2 r�pertoires partag�s du serveur 8.2 vers le serveur 9.7) dans une base 9.7
			Les param�tres suivants de la base migr�e sont mis � AUTO :
					SELF_TUNING_MEM
					dbheap
					STMTHEAP
					maxlocks
					locklist
					NUM_IOSERVERS
					NUM_IOCLEANERS
					
		- Revalidation des objets syst�me: CALL SYSPROC.ADMIN_REVALIDATE_DB_OBJECTS(NULL, 'SYSIBMADM', NULL)
		- binds (db2rbind)
		- Il n'y a pas de reorgs ni de runstats		
		- Backup de la base interm�diaire 9.7 
		
0.3 => sur le serveur 11.1 (idem 9.7):
			
		- restore du backup 9.7 vers une base 11.1
		- Param�tres mis a AUTO (les memes que pour le restore 9.7)
		- reorg de toutes les tables 
		- runstats sur toutes les tables 
		- Revalidation des objets syst�me: CALL SYSPROC.ADMIN_REVALIDATE_DB_OBJECTS(NULL, 'SYSIBMADM', NULL)
		- binds (db2rbind)
		
1 - Mise en place pr�alable :
=========================
La mise en place se fait pour chaque instance.
Toutes les op�rations prennent comme exemple les migrations effectu�es pour :
- serveur REC/RIT: QS03518/QS03519 => QS83057
- instance wbcpirf
- base W5DMETRO

Sur le serveur de destination, sur les instances 9.7 de transit et 11.1 destination , v�rifier la configuration du dbm cfg: 

 db2 get dbm cfg |grep DFTDBPATH
 
 On doit avoir ceci: 
  Default database path                       (DFTDBPATH) = /ClientGrpEtlBd_ret/data/db
  
  et SURTOUT PAS CECI !!!! (DFTDBPATH) = /ClientGrpEtlBd_ret/data/db/wbcipirf 
														ou 
													  /ClientGrpEtlBd_ret/data/db/db2rtn3
													  
Il ne faut pas que le nom de l'instance fasse partie du DFTDBPATH (sinon le restore recr�e une arborescence compl�te dans le FS par d�faut)

2 - Sur le serveur DB2 AIX DPF 8.2 (QS03518/QS03519) : 
--------------------------------------------------
2.1 - cr�er le r�pertoire: "maitre" ou seront stock�s les backups 8.2 et les scripts

2.2 - sur le serveur QS03518
cd /ClientGrpBcu_rec/backup/db/wbcpirf <== Les backups courants
mkdir migrat
cd migrat 
mkdir LOT1
chmod 777 LOT1 
mkdir scripts

2.3 - sur le serveur QS03519
cd /ClientGrpBcu_rec/backup/db/wbcpirf
mkdir migrat
cd migrat 
mkdir LOT1
chmod 777 LOT1 

2.4 Dans le repertoire migrat/scripts, copier les fichiers:
	- pbckallix.sh
	- pbckallix.properties
	
	chmod 775 pbckallix.*
	
2.5	Dans le fichier de properties, modifier la ligne suivante comme suit:
		export BCKPDIR=/ClientGrpBcu_rec/backup/db/wbcpirf/migrat   (r�pertoire "maitre" du backup 8.2)		

3 - Sur le serveur DB2 AIX DPF 9.7 (QS83057) : 
--------------------------------------------------
3.1 - v�rifier que l'instance DPF "de transition" 9.7 db2rtn3 a bien le meme nombre de nodes que l'instance 8.2

3.2 - avec le user db2rtn3:
		cd /ClientGrpEtlBd_ret/bk/db2rtn3
		mkdir migrat
		cd migrat
		mkdir LOT1
		chmod 777 LOT1 
		cd LOT1
		mkdir 82_97
		mkdir 97_11
		chmod 777 82_97
		chmod 777 97_11
		mkdir scripts 

		copier les 2 scripts:
			prestbck97.sh
			prestbck97.properties
		
		chmod 777 prestbck97.*
		
		Modifier le fichier de properties:
		
		export DB97_DIR=/ClientGrpEtlBd_ret/bk/db2rtn3/migrat   <============= Repertoire principal de la migration 9.7

		export BCK82_0=/ClientGrpBcu_rec/backup/db/QS03518/wbcpirf/migrat <<===== Repertoire principal du backup 8.2 node 0
		export BCK82_n=/ClientGrpBcu_rec/backup/db/QS03519/wbcpirf/migrat <<===== Repertoire principal du backup 8.2 autres nodes

3.3 - Lancer le script (restore 8.2 -> 9.7 et backup 9.7)

		nohup ./prestbckix97.sh LOT1 > prestbckix97_LOT1_20180909.log &
		
		
4 - Sur le serveur DB2 AIX DPF 11.1 (QS83057) : 
--------------------------------------------------		
4.1 - v�rifier que l'instance DPF 11.1 a bien le meme nombre de nodes que l'instance 8.2
	   V�rifier que l'instance DPF 11.1 a bien les droits sur le r�pertoire "de transition" 9.7

4.2 - avec le user wbcpirf (user d'instance 11.1):
			cd /ClientGrpEtlBd_ret/bk/wbcpirf
			mkdir migrat
			cd migrat
			mkdir scripts
			cd scripts
			
			copier les 2 scripts:
					prestix11.properties
					prestix11.sh
					
			Modifier le fichier properties: 
					export DB97_DIR=/ClientGrpEtlBd_ret/bk/db2rtn3/migrat <<== Nom du repertoire principal du backup 9.7
							(le backup lui meme est dans le repertoire: /ClientGrpEtlBd_ret/bk/db2rtn3/migrat/LOT1 )
					export DBCK11=/tmp <== Nom du repertoire de backup base Version 11
		
Lancement:
====================================================

sur le serveur 8.2 (QS03518):
		
	su - wbcpirf
	Cr�er le fichier de "top", qui indique la base � migrer:
	cd /ClientGrpBcu_rec/backup/db/wbcpirf/LOT1
	touch W5DMETRO.todo
	chmod 777 W5DMETRO.todo
	
	Lancer le backup 8.2:
	nohup ./pbckallix.sh LOT1 > pbckix_LOT1_20180919.log &		
	
	A la fin du job, on doit avoir:
		- les fichiers de backup accessibles depuis le serveur 9.7 
		le fichier: W5DMETRO.bckok qui indique que le backup de la base W5DMETRO a ete fait et est disponible pour la migration
	
	
sur le serveur 9.7 (QS83057):
	
	su - db2rtn3
	cd /ClientGrpEtlBd_ret/bk/db2rtn3/migrat/scripts
	----
	----
	===>>  Avant le lancement du script, supprimer manuellement les fichiers du run pr�c�dent dans le r�pertoire: LOT1/97_11
	----
	----
	
	nohup ./prestbck97.sh LOT1 > prestbck97_wbcpirf_LOT1_20180920.log &
	
	Si la base 9.7 existe deja, le job s'arrete.
	A la fin du job, il y a:
	dans le repertoire LOT1 (du serveur 9.7) le fichier W5DMETRO.bckok97 
	les fichiers de backup de la base 9.7 
	
sur le serveur 11.1 (QS83057):	

	su - wbcpirf
	/ClientGrpEtlBd_ret/bk/wbcpirf/migrat/scripts
	nohup ./prestix11.sh LOT1 > prestix11_LOT1_20180920.log &
	
	Si la base 11.1 existe, le job s'arrete
	A la fin du job, il y a:
	dans le repertoire LOT1 (du serveur 11.1) le fichier W5DMETRO.done11 (a supprimer si l'on veut refaire la migration !!! )
			
	La base 11.1 restoree est disponible
	
PREREQ:
====================================================================

LES REPERTOIRES DES BACKUPS 8.2 DOIVENT ETRE ACCESSIBLES PAR NFS DEPUIS LE SERVEUR 9.7 

====================================================================	

Points divers/erreurs:	
----------------------
- Bien v�rifier au pr�alable les droits (777) pour les r�pertoires (le r�pertoire 9.7 doit �tre accessible par le user d'instance 11.1)
- Les r�pertoires des backups 8.2 doivent �tre accessibles via NFS par le serveur 9.7 
		(restore direct 9.7 depuis ces r�pertoires).
		
- bien sp�cifier le nom du LOT lors du lancement du shell, par exemple, 
		NE PAS FAIRE: prestbck97.sh > fichier.log, 
		mais			: prestbck97.sh  LOT1 > fichier.log 
		
- s'assurer de la disponibilit� des instances avec le bon nombre de node

- v�rifier dans le dbm cfg le dftdbpatch, il NE DOIT pas comprendre le nom d'instance qui est ajout� par db2 lors du restore 
	(mais il doit exister dans le FS )
	
- Espace disque pour:
		- Base 9.7 interm�diaire
		- backup base 9.7 interm�diaire
		- Base 11.1
	
	
	FIN DU DOCUMENT


