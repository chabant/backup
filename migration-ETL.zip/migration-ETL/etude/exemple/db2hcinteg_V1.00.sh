#db2 -x "select 'set integrity for '||trim(tabschema)||'.'||trim(tabname)||' immediate checked;' from syscat.tables where status <> 'N' and type = 'T' order by tabschema,tabname;"
# db2 -x "select trim(tabschema)||'.'||trim(tabname)||' to check'  from syscat.tables where status <> 'N' order by tabschema,tabname"
export DBNAME=$1


# -------------------------------------
#   set integrity after load
# -------------------------------------
echo "begin set integrity : `date` "
rm -f check.sql
db2 connect to ${DBNAME}
db2 -x "select 'SET INTEGRITY FOR '|| TABSCHEMA ||'.'||TABNAME || ' IMMEDIATE CHECKED ;' from SYSCAT.TABLES where STATUS='C' and type='T'" > check.sql

tabcnt=$(cat check.sql | wc -l )
echo " tabcnt: " ${tabcnt}
while [ ${tabcnt} -gt 0 ] ; do
    db2 -tvf check.sql
    db2 -x "select 'SET INTEGRITY FOR '|| TABSCHEMA ||'.'||TABNAME || ' IMMEDIATE CHECKED ;' from SYSCAT.TABLES where STATUS='C' and type='T'" > check.sql
    tabcnt=$(cat check.sql | wc -l )
    echo " tabcnt: " ${tabcnt}
done

db2 terminate

echo " Fin  set integrity : `date` "

