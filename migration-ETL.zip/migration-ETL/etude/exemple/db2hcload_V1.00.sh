export DBNAME=$1
export SCH_SRC=$2
export SCH_DST=$3
export CMDLOADFILE=db2hcload.${SCH_DST}.sql.err
export CMDMSGERRFILE=db2hcload.${SCH_DST}.err

rm -f *.msg
rm -f ${CMDLOADFILE}
rm -f ${CMDMSGERRFILE}
touch ${CMDLOADFILE}
touch ${CMDMSGERRFILE}

db2 connect to ${DBNAME}

for FILE in `ls ${SCH_SRC}.*.ixf`
    do
    TABFULLNAME=${FILE%.*}
    TABNAME=`echo $TABFULLNAME |cut -d. -f 2`
    MODIFIER=""
    CMDIDENT="select count(1) from syscat.COLumns  where tabschema = '${SCH_DST}' and tabname ='${TABNAME}' and identity='Y' and generated='A' "
    cnt=`db2 -x $CMDIDENT`
    if [ "${cnt}" -ne 0 ]
       then
        echo "identite: ==> " ${SCH_DST} ${TABNAME}
        MODIFIER="modified by identityoverride"
      fi

    CMDLOAD="load from ${FILE} of ixf lobs from . ${MODIFIER} messages  ${SCH_DST}.${TABNAME}.msg replace into ${SCH_DST}.${TABNAME} nonrecoverable"
    db2 -v ${CMDLOAD}
    rc=$?
    if [ "${rc}" -ne 0 ]
        then
        echo "LOAD problem return code: ${rc} table: ${TABFULLNAME}"
        cat $TABFULLNAME.msg >> $CMDMSGERRFILE
        echo $CMDLOAD >> $CMDLOADFILE
        fi

done

