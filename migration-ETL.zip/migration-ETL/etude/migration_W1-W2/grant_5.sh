#!/bin/sh
#
# This script will grant privileges for  user on Hybrid Cloud Database
#

export DBNAME=${1}
export TUSER=${2}


date

#-- validation of numbers of inputs
if [ $# -ne 2 ]
then
   echo "$?  <Database Name>=$1 <User>=$2 "
   exit 1
fi

#-- connection to db
db2 -v CONNECT TO ${DBNAME}


#-- grant
db2 -v grant CONNECT,LOAD,BINDADD,CREATETAB,IMPLICIT_SCHEMA,DATAACCESS  on database to ${TUSER}


#-- disconnect to db
db2 -v CONNECT RESET
db2 -v TERMINATE


#-- END


 