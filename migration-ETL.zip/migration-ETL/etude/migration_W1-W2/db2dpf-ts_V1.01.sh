SQLIN=$1



sed  -e  "1,$ s/MANAGED BY DATABASE/MANAGED BY AUTOMATIC STORAGE/g" \
     -e  "1,$ s/MANAGED BY SYSTEM/MANAGED BY AUTOMATIC STORAGE/g"   \
     -e  "/FILE '/d"  \
     -e  "1,$ s/USING (.*)//g" $SQLIN > db2_ts_auto.tmp


sed  -e  "/DBPARTITIONNUMS/d;/,/d;/);/d" \
     -e  "/DBPARTITIONNUM/d" \
     -e  "1,$ s/IN DATABASE PARTITION GROUP .* PAGESIZE/PAGESIZE/g"  db2_ts_auto.tmp > db2_ts_auto.sql

rm db2_ts_auto.tmp




