#!/bin/sh
#


DBCIBLE=${1}



date

#-- validation of numbers of inputs
if [ $# -ne 1 ]
then
   echo "$?  <Database Name>=$1 "
   exit 1
fi

#-- connection to db
db2 -v connect to ${DBCIBLE}


TABLES=$(db2 -x "select trim(tabschema)||'.'||trim(tabname) from syscat.tables where type = 'T' and tabschema not in ('SYSIBM','SYSTOOLS') and tabname not like '%EXPLAIN_%' order by trim(tabschema)||'.'||trim(tabname)")



for tbl in ${TABLES}
do
	echo $tbl
	echo 'nb de lignes:'
    db2 -x "select count(*) from ${tbl}"  
    echo 'nb de colonnes:'	
	db2 -x "select colcount from syscat.tables where trim(tabschema)||'.'||trim(tabname)=${tbl}"
done
db2 CONNECT RESET;
db2 TERMINATE;