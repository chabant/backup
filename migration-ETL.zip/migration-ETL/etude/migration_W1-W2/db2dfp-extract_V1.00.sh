#!/bin/sh
# 
# Extract the DDL for tablespaces for DPF database
#

SQLIN=$1 


exec pwd |read DIRECTORY

# extract ddl for tablespaces for DPF database : db2look -d WMDWCLI1 -l -o /tmp/mig-ETL/WMDWCLI1_ts.sql
db2look -d ${SQLIN} -l -o ${DIRECTORY}/${SQLIN}_ts.sql

# check if SYSTOOLS.DB2LOOK_INFO table exist
db2 connect to ${SQLIN}
db2 "select count(*) from SYSTOOLS.DB2LOOK_INFO where SQL_STMT like '%TABLESPACE%'"

if [ $? -ne 0 ]; then
   echo "SYSTOOLS.DB2LOOK_INFO table doesn't exist"
   db2 "call SYSPROC.DB2LK_GENERATE_DDL('-l',?)"   
fi

## SYSTOOLS.DB2LOOK_INFO table exist , we export the contains
db2 "export to ${SQLIN}_all_ts.sql of DEL select SQL_STMT||';' from SYSTOOLS.DB2LOOK_INFO where SQL_STMT like '%TABLESPACE%'"
db2 connect reset


# extract ddl for tables for DPF database : db2look -d WMDWCLI1 -e  -o /tmp/mig-ETL/WMDWCLI1_all_ddl.sql
db2look -d ${SQLIN} -e -o ${DIRECTORY}/${SQLIN}_all_ddl.sql


# extract ddl for grants for DPF database : db2look -d WMDWCLI1 -xd -o /tmp/mig-ETL/WMDWCLI1_all_grants.sql
db2look -d ${SQLIN} -xd -o ${DIRECTORY}/${SQLIN}_all_grants.sql
