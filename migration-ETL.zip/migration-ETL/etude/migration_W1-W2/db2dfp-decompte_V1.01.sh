#!/bin/sh
#

DBSOURCE='SOURCE'
SRCUSER=${2}
DBCIBLE=${1}

export SRCFILE=${1}'-Source.log'
export TGTFILE=${1}'-Target.log'


date

#-- validation of numbers of inputs
if [ $# -ne 2 ]
then
   echo "$?  <Source DB User>=$1 <Target Database Name>=$2 "
   exit 1
fi


echo "********" > ${SRCFILE}
echo "********" > ${TGTFILE}


#-- connection to source db
db2 -v connect to ${DBSOURCE} user ${SRCUSER}


TABLES=$(db2 -x "select trim(tabschema)||'.'||trim(tabname) from syscat.tables where type = 'T' and tabschema not in ('SYSIBM','SYSTOOLS') and tabname not like '%EXPLAIN_%' order by trim(tabschema)||'.'||trim(tabname)")



for tbl in ${TABLES}
do
	echo $tbl >> ${SRCFILE}
	echo 'nb de lignes:' >> ${SRCFILE}
    db2 -x "select count(*) from ${tbl}"  >> ${SRCFILE}
    echo 'nb de colonnes:'	>> ${SRCFILE}
	db2 -x "select colcount from syscat.tables where (trim(tabschema)||'.'||trim(tabname))='${tbl}'" >> ${SRCFILE}
done
db2 CONNECT RESET;

#-- connection to target db
db2 -v connect to ${DBCIBLE}

for tbl in ${TABLES}
do
	echo $tbl >> ${TGTFILE}
	echo 'nb de lignes:' >> ${TGTFILE}
    db2 -x "select count(*) from ${tbl}"  >> ${TGTFILE}
    echo 'nb de colonnes:'	>> ${TGTFILE}
	db2 -x "select colcount from syscat.tables where (trim(tabschema)||'.'||trim(tabname))='${tbl}'" >> ${TGTFILE}
done
db2 CONNECT RESET;

db2 TERMINATE;


diff -b ${SRCFILE} ${TGTFILE} > ${DBCIBLE}'-diff.log'


#
# End
#
