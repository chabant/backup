export DBNAME=${1}
export FILECMD=db2exp_${DBNAME}.sql
export EXPORT_LOGFILE=db2exp_${DBNAME}.log
export ERRORFILE=db2exp_${DBNAME}.err

rm -f $FILECMD
rm -f $EXPORT_LOGFILE
rm -f $ERRORFILE
rm -f *.ixf
rm -f *.lob

touch $ERRORFILE
chmod 777 $ERRORFILE

set -o noglob

CMD1="select 'export to '||trim(tabschema)||'.'||tabname||'.ixf of ixf '||'lobs to . modified by lobsinfile ' "
CMD2="|| 'select * from '||trim(tabschema)||'.'||tabname "
CMD3="from syscat.tables where type = 'T' and tabschema not in ('SYSIBM','SYSTOOLS') and tabname not like '%EXPLAIN_%' order by tabschema,tabname "

db2 connect to ${DBNAME}

db2 -x $CMD1$CMD2$CMD3 > $FILECMD

while read LIGNE
do
db2 -x  $LIGNE  >> $EXPORT_LOGFILE
rc=$?
if [ "$rc" != "0" ]
   then
        echo "KO !!!!!!!!!!!!!!!!!!!"
        echo $LIGNE >> $ERRORFILE
   fi
done < $FILECMD

set +o noglob


