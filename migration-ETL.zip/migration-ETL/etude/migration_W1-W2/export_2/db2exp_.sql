SQL1024N  A database connection does not exist.  SQLSTATE=08003
