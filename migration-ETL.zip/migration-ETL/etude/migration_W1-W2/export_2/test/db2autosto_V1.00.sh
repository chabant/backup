SQLIN=$1

cp $SQLIN $SQLIN.init-1
rm $SQLIN


sed  -e  "1,$ s/MANAGED BY DATABASE/MANAGED BY AUTOMATIC STORAGE/g" \
     -e  "1,$ s/MANAGED BY SYSTEM/MANAGED BY AUTOMATIC STORAGE/g"   \
     -e  "/FILE '/d"  \
     -e  "1,$ s/USING (.*)//g" $SQLIN.init-1 > $SQLIN



