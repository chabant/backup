SQLIN=$1

sed  -e  "1,$ s/IN DATABASE PARTITION GROUP .* PAGESIZE/PAGESIZE/g"  db2_dfp-B.sql > db2_dfp-C.sql



