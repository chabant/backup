SQLIN=$1

sed  -e  "/DBPARTITIONNUMS/d;/,/d;/);/d" $SQLIN > db2_dfp-A.sql


