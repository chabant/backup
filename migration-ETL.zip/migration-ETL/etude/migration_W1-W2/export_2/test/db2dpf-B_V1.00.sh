SQLIN=$1

sed  -e  "/DBPARTITIONNUM/d" $SQLIN > db2_dfp-B.sql


