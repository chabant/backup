SQLIN=$1

cp $SQLIN $SQLIN.init-2
rm $SQLIN

sed  -e  "/DBPARTITIONNUMS/d;/,/d;/);/d" \
     -e  "/DBPARTITIONNUM/d" \
     -e  "1,$ s/IN DATABASE PARTITION GROUP .* PAGESIZE/PAGESIZE/g"  $SQLIN.init-2 > $SQLIN



