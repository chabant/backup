SQLIN=$1

sed  -e  "1,$ s/IN DATABASE PARTITION GROUP IBMTEMPGROUP//g"  db2_dfp-B.sql > db2_dfp-C1.sql
sed  -e  "1,$ s/IN DATABASE PARTITION GROUP IBMCATGROUP//g"  db2_dfp-C1.sql > db2_dfp-C2.sql
sed  -e  "1,$ s/IN DATABASE PARTITION GROUP DBPARTGROUP1//g"  db2_dfp-C2.sql > db2_dfp-C3.sql


