SQLIN=$1

mv $SQLIN $SQLIN.init

sed  -e  "1,$ s/MANAGED BY DATABASE/MANAGED BY AUTOMATIC STORAGE/g" \
     -e  "1,$ s/MANAGED BY SYSTEM/MANAGED BY AUTOMATIC STORAGE/g"   \
     -e  "/FILE '/d"  \
     -e  "1,$ s/USING (.*)//g" $SQLIN.init > $SQLIN.tmp


sed  -e  "/DBPARTITIONNUMS/d;/,/d;/);/d" \
     -e  "/DBPARTITIONNUM/d" \
     -e  "1,$ s/IN DATABASE PARTITION GROUP .* PAGESIZE/PAGESIZE/g"  $SQLIN.tmp > $SQLIN.tmp2
sed  -e  "s/IN DATABASE PARTITION GROUP .*//g" $SQLIN.tmp2 > $SQLIN

#rm $SQLIN.tmp $SQLIN.tmp2




