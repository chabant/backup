SQLIN=$1

cp $SQLIN $SQLIN.init
rm $SQLIN

sed  -e  "/DISTRIBUTE BY HASH/d"  $SQLIN.init > $SQLIN

