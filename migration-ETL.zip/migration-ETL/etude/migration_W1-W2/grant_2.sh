#!/bin/sh
#
# This script will grant privileges for  user on Hybrid Cloud Database
#

export DBNAME=${1}
export TUSER=${2}


date

#-- validation of numbers of inputs
if [ $# -ne 2 ]
then
   echo "$?  <Database Name>=$1 <User>=$2 "
   exit 1
fi

#-- connection to db
db2 -v CONNECT TO ${DBNAME}




#-- grant
db2 -v grant CONNECT,LOAD,BINDADD,CREATETAB,IMPLICIT_SCHEMA on database to ${TUSER}
db2 -v grant execute on package NULLID.SQLC2P31 to ${TUSER}

db2 -v grant select  on table SYSCAT.ATTRIBUTES to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.AUDITPOLICIES to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.AUDITUSE to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.BUFFERPOOLDBPARTITIONS to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSCAT.BUFFERPOOLEXCEPTIONS to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSCAT.BUFFERPOOLNODES to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSCAT.BUFFERPOOLS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.CASTFUNCTIONS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.CHECKS to ${TUSER}                                                                                                                     
db2 -v grant select  on table SYSCAT.COLAUTH to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.COLCHECKS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.COLDIST to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.COLGROUPCOLS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.COLGROUPDIST to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.COLGROUPDISTCOUNTS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSCAT.COLGROUPS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.COLIDENTATTRIBUTES to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSCAT.COLLATIONS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.COLOPTIONS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.COLUMNS to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.COLUSE to ${TUSER}                                                                                                                     
db2 -v grant select  on table SYSCAT.CONDITIONS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.CONSTDEP to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.CONTEXTATTRIBUTES to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSCAT.CONTEXTS to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.CONTROLDEP to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.CONTROLS to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.DATAPARTITIONEXPRESSION to ${TUSER}                                                                                                    
db2 -v grant select  on table SYSCAT.DATAPARTITIONS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.DATATYPEDEP to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.DATATYPES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.DBAUTH to ${TUSER}                                                                                                                     
db2 -v grant select  on table SYSCAT.DBPARTITIONGROUPDEF to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSCAT.DBPARTITIONGROUPS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSCAT.EVENTMONITORS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.EVENTS to ${TUSER}                                                                                                                     
db2 -v grant select  on table SYSCAT.EVENTTABLES to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.FULLHIERARCHIES to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSCAT.FUNCDEP to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.FUNCMAPOPTIONS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.FUNCMAPPARMOPTIONS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSCAT.FUNCMAPPINGS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.FUNCPARMS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.FUNCTIONS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.HIERARCHIES to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.HISTOGRAMTEMPLATEBINS to ${TUSER}                                                                                                      
db2 -v grant select  on table SYSCAT.HISTOGRAMTEMPLATES to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSCAT.HISTOGRAMTEMPLATEUSE to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSCAT.INDEXAUTH to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.INDEXCOLUSE to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.INDEXDEP to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.INDEXES to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.INDEXEXPLOITRULES to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSCAT.INDEXEXTENSIONDEP to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSCAT.INDEXEXTENSIONMETHODS to ${TUSER}                                                                                                      
db2 -v grant select  on table SYSCAT.INDEXEXTENSIONPARMS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSCAT.INDEXEXTENSIONS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSCAT.INDEXOPTIONS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.INDEXPARTITIONS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSCAT.INDEXXMLPATTERNS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSCAT.INVALIDOBJECTS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.KEYCOLUSE to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.LIBRARIES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.LIBRARYAUTH to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.LIBRARYBINDFILES to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSCAT.LIBRARYVERSIONS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSCAT.MEMBERSUBSETATTRS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSCAT.MEMBERSUBSETMEMBERS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSCAT.MEMBERSUBSETS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.MODULEAUTH to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.MODULEOBJECTS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.MODULES to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.NAMEMAPPINGS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.NICKNAMES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.NODEGROUPDEF to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.NODEGROUPS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.PACKAGEAUTH to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.PACKAGEDEP to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.PACKAGES to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.PARTITIONMAPS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.PASSTHRUAUTH to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.PERIODS to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.PREDICATESPECS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.PROCEDURES to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.PROCPARMS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.REFERENCES to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.ROLEAUTH to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.ROLES to ${TUSER}                                                                                                                      
db2 -v grant select  on table SYSCAT.ROUTINEAUTH to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.ROUTINEDEP to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.ROUTINEOPTIONS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.ROUTINEPARMOPTIONS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSCAT.ROUTINEPARMS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.ROUTINES to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.ROUTINESFEDERATED to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSCAT.ROWFIELDS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.SCHEMAAUTH to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.SCHEMATA to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.SCPREFTBSPACES to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.SECURITYLABELACCESS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSCAT.SECURITYLABELCOMPONENTELEMENTS to ${TUSER}                                                                                             
db2 -v grant select  on table SYSCAT.SECURITYLABELCOMPONENTS to ${TUSER}                                                                                                    
db2 -v grant select  on table SYSCAT.SECURITYLABELS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.SECURITYPOLICIES to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSCAT.SECURITYPOLICYCOMPONENTRULES to ${TUSER}                                                                                               
db2 -v grant select  on table SYSCAT.SECURITYPOLICYEXEMPTIONS to ${TUSER}                                                                                                   
db2 -v grant select  on table SYSCAT.SEQUENCEAUTH to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.SEQUENCES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.SERVEROPTIONS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.SERVERS to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.SERVICECLASSES to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.STATEMENTS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.STATEMENTTEXTS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.STOGROUPS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.SURROGATEAUTHIDS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSCAT.TABAUTH to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.TABCONST to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.TABDEP to ${TUSER}                                                                                                                     
db2 -v grant select  on table SYSCAT.TABDETACHEDDEP to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.TABLES to ${TUSER}                                                                                                                     
db2 -v grant select  on table SYSCAT.TABLESPACES to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.TABOPTIONS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.TBSPACEAUTH to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.THRESHOLDS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.TRANSFORMS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.TRIGDEP to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.TRIGGERS to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.TYPEMAPPINGS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.USAGELISTS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.USEROPTIONS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.VARIABLEAUTH to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.VARIABLEDEP to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.VARIABLES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.VIEWDEP to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSCAT.VIEWS to ${TUSER}                                                                                                                      
db2 -v grant select  on table SYSCAT.WORKACTIONS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.WORKACTIONSETS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSCAT.WORKCLASSATTRIBUTES to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSCAT.WORKCLASSES to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.WORKCLASSSETS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.WORKLOADAUTH to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.WORKLOADCONNATTR to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSCAT.WORKLOADS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSCAT.WRAPOPTIONS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSCAT.WRAPPERS to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSCAT.XDBMAPGRAPHS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.XDBMAPSHREDTREES to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSCAT.XMLSTRINGS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSCAT.XSROBJECTAUTH to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSCAT.XSROBJECTCOMPONENTS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSCAT.XSROBJECTDEP to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSCAT.XSROBJECTDETAILS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSCAT.XSROBJECTHIERARCHIES to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSCAT.XSROBJECTS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.CHECK_CONSTRAINTS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.COLUMNS to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSIBM.COLUMNS_S to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.DUAL to ${TUSER}                                                                                                                       
db2 -v grant select  on table SYSIBM.PARAMETERS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.PARAMETERS_S to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.REF_CONSTRAINTS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.REFERENTIAL_CONSTRAINTS to ${TUSER}                                                                                                    
db2 -v grant select  on table SYSIBM.ROUTINES to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSIBM.ROUTINES_S to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SQLCOLPRIVILEGES to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SQLCOLUMNS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SQLFOREIGNKEYS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SQLPRIMARYKEYS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SQLPROCEDURECOLS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SQLPROCEDURES to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SQLSCHEMAS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SQLSPECIALCOLUMNS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SQLSTATISTICS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SQLTABLEPRIVILEGES to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SQLTABLES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.SQLTABLETYPES to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SQLTYPEINFO to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SQLUDTS to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSIBM.SYSATTRIBUTES to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSAUDITEXCEPTIONS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SYSAUDITPOLICIES to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSAUDITUSE to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSBUFFERPOOLNODES to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SYSBUFFERPOOLS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSCHECKS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.SYSCODEPROPERTIES to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSCOLAUTH to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSCOLCHECKS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSCOLDEPENDENCIES to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SYSCOLDIST to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSCOLGROUPDIST to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSCOLGROUPDISTCOUNTS to ${TUSER}                                                                                                      
db2 -v grant select  on table SYSIBM.SYSCOLGROUPS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSCOLGROUPSCOLS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSCOLLATIONS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSCOLOPTIONS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSCOLPROPERTIES to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSCOLUMNS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSCOLUSE to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.SYSCOMMENTS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSCONSTDEP to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSCONTEXTATTRIBUTES to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBM.SYSCONTEXTS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSCONTROLS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSDATAPARTITIONEXPRESSION to ${TUSER}                                                                                                 
db2 -v grant select  on table SYSIBM.SYSDATAPARTITIONS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSDATATYPES to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSDBAUTH to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.SYSDEPENDENCIES to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSDUMMY1 to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.SYSENVIRONMENT to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSEVENTMONITORS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSEVENTS to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.SYSEVENTTABLES to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSFUNCMAPOPTIONS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSFUNCMAPPARMOPTIONS to ${TUSER}                                                                                                      
db2 -v grant select  on table SYSIBM.SYSFUNCMAPPINGS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSFUNCPARMS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSFUNCTIONS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSHIERARCHIES to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSHISTOGRAMTEMPLATEBINS to ${TUSER}                                                                                                   
db2 -v grant select  on table SYSIBM.SYSHISTOGRAMTEMPLATES to ${TUSER}                                                                                                      
db2 -v grant select  on table SYSIBM.SYSHISTOGRAMTEMPLATEUSE to ${TUSER}                                                                                                    
db2 -v grant select  on table SYSIBM.SYSINDEXAUTH to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSINDEXCOLUSE to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSINDEXES to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSINDEXEXPLOITRULES to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBM.SYSINDEXEXTENSIONMETHODS to ${TUSER}                                                                                                   
db2 -v grant select  on table SYSIBM.SYSINDEXEXTENSIONPARMS to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSIBM.SYSINDEXEXTENSIONS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SYSINDEXOPTIONS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSINDEXPARTITIONS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SYSINDEXXMLPATTERNS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBM.SYSINVALIDOBJECTS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSJARCONTENTS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSJAROBJECTS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSJOBS to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSIBM.SYSKEYCOLUSE to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSLIBRARIES to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSLIBRARYAUTH to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSLIBRARYBINDFILES to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBM.SYSLIBRARYVERSIONS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SYSMEMBERSUBSETATTRS to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBM.SYSMEMBERSUBSETMEMBERS to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSIBM.SYSMEMBERSUBSETS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSMODULEAUTH to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSMODULES to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSNAMEMAPPINGS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSNODEGROUPDEF to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSNODEGROUPS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSPARTITIONMAPS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSPASSTHRUAUTH to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSPERIODS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSPLAN to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSIBM.SYSPLANAUTH to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSPLANDEP to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSPREDICATESPECS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSPROCEDURES to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSPROCPARMS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSRELS to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSIBM.SYSREVTYPEMAPPINGS to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.SYSROLEAUTH to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSROLES to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSIBM.SYSROUTINEAUTH to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSROUTINEOPTIONS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSROUTINEPARMOPTIONS to ${TUSER}                                                                                                      
db2 -v grant select  on table SYSIBM.SYSROUTINEPARMS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSROUTINEPROPERTIES to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBM.SYSROUTINEPROPERTIESJAVA to ${TUSER}                                                                                                   
db2 -v grant select  on table SYSIBM.SYSROUTINES to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSSCHEMAAUTH to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSSCHEMATA to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSSCPREFTBSPACES to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSSECTION to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSSECURITYLABELACCESS to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSIBM.SYSSECURITYLABELCOMPONENTELEMENTS to ${TUSER}                                                                                          
db2 -v grant select  on table SYSIBM.SYSSECURITYLABELCOMPONENTS to ${TUSER}                                                                                                 
db2 -v grant select  on table SYSIBM.SYSSECURITYLABELS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSSECURITYPOLICIES to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBM.SYSSECURITYPOLICYCOMPONENTRULES to ${TUSER}                                                                                            
db2 -v grant select  on table SYSIBM.SYSSECURITYPOLICYEXEMPTIONS to ${TUSER}                                                                                                
db2 -v grant select  on table SYSIBM.SYSSEQUENCEAUTH to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSSEQUENCES to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSSERVEROPTIONS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSSERVERS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSSERVICECLASSES to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSSTATEMENTTEXTS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSSTMT to ${TUSER}                                                                                                                    
db2 -v grant select  on table SYSIBM.SYSSTOGROUPS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSSURROGATEAUTHIDS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBM.SYSTABAUTH to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSTABCONST to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSTABLES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBM.SYSTABLESPACES to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSTABOPTIONS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSTASKS to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSIBM.SYSTBSPACEAUTH to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSTHRESHOLDS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSTRANSFORMS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSTRIGGERS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSTUNINGINFO to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSTYPEMAPPINGS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSUPGRADERUNSTATSTASKS to ${TUSER}                                                                                                    
db2 -v grant select  on table SYSIBM.SYSUSAGELISTS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSUSERAUTH to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSUSEROPTIONS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSVARIABLEAUTH to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSVARIABLES to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSVERSIONS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSVIEWDEP to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBM.SYSVIEWS to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSIBM.SYSWORKACTIONS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSWORKACTIONSETS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.SYSWORKCLASSATTRIBUTES to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSIBM.SYSWORKCLASSES to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSWORKCLASSSETS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSWORKLOADAUTH to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSWORKLOADCONNATTR to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBM.SYSWORKLOADS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBM.SYSWRAPOPTIONS to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBM.SYSWRAPPERS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSXDBMAPGRAPHS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBM.SYSXDBMAPSHREDTREES to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBM.SYSXMLPATHS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBM.SYSXMLSTRINGS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.SYSXSROBJECTAUTH to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBM.SYSXSROBJECTCOMPONENTS to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSIBM.SYSXSROBJECTHIERARCHIES to ${TUSER}                                                                                                    
db2 -v grant select  on table SYSIBM.SYSXSROBJECTS to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBM.TABLE_CONSTRAINTS to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBM.TABLES to ${TUSER}                                                                                                                     
db2 -v grant select  on table SYSIBM.TABLES_S to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSIBM.UDT_S to ${TUSER}                                                                                                                      
db2 -v grant select  on table SYSIBM.USER_DEFINED_TYPES to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBM.VIEWS to ${TUSER}                                                                                                                      
db2 -v grant select  on table SYSIBMADM.ADMINTABINFO to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBMADM.ADMINTEMPCOLUMNS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBMADM.ADMINTEMPTABLES to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBMADM.APPL_PERFORMANCE to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBMADM.APPLICATIONS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBMADM.AUTHORIZATIONIDS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBMADM.BP_HITRATIO to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBMADM.BP_READ_IO to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBMADM.BP_WRITE_IO to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBMADM.CONTACTGROUPS to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.CONTACTS to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBMADM.CONTAINER_UTILIZATION to ${TUSER}                                                                                                   
db2 -v grant select  on table SYSIBMADM.DB_HISTORY to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBMADM.DB2_INSTANCE_ALERTS to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSIBMADM.DBCFG to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSIBMADM.DBMCFG to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBMADM.DBPATHS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBMADM.ENV_CF_SYS_RESOURCES to ${TUSER}                                                                                                    
db2 -v grant select  on table SYSIBMADM.ENV_FEATURE_INFO to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBMADM.ENV_INST_INFO to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.ENV_PROD_INFO to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.ENV_SYS_INFO to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBMADM.ENV_SYS_RESOURCES to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBMADM.LOCKS_HELD to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBMADM.LOCKWAITS to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBMADM.LOG_UTILIZATION to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBMADM.LONG_RUNNING_SQL to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBMADM.MON_TRANSACTION_LOG_UTILIZATION to ${TUSER}                                                                                         
db2 -v grant select  on table SYSIBMADM.NOTIFICATIONLIST to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBMADM.OBJECTOWNERS to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBMADM.PDLOGMSGS_LAST24HOURS to ${TUSER}                                                                                                   
db2 -v grant select  on table SYSIBMADM.PRIVILEGES to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSIBMADM.QUERY_PREP_COST to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSIBMADM.REG_VARIABLES to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.SNAPAGENT to ${TUSER}                                                                                                               
db2 -v grant select  on table SYSIBMADM.SNAPAGENT_MEMORY_POOL to ${TUSER}                                                                                                   
db2 -v grant select  on table SYSIBMADM.SNAPAPPL to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBMADM.SNAPAPPL_INFO to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.SNAPBP to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBMADM.SNAPBP_PART to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBMADM.SNAPCONTAINER to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.SNAPDB to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSIBMADM.SNAPDB_MEMORY_POOL to ${TUSER}                                                                                                      
db2 -v grant select  on table SYSIBMADM.SNAPDBM to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBMADM.SNAPDBM_MEMORY_POOL to ${TUSER}                                                                                                     
db2 -v grant select  on table SYSIBMADM.SNAPDETAILLOG to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.SNAPDYN_SQL to ${TUSER}                                                                                                             
db2 -v grant select  on table SYSIBMADM.SNAPFCM to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBMADM.SNAPFCM_PART to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBMADM.SNAPHADR to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBMADM.SNAPLOCK to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBMADM.SNAPLOCKWAIT to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBMADM.SNAPSTMT to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBMADM.SNAPSTORAGE_PATHS to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBMADM.SNAPSUBSECTION to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBMADM.SNAPSWITCHES to ${TUSER}                                                                                                            
db2 -v grant select  on table SYSIBMADM.SNAPTAB to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSIBMADM.SNAPTAB_REORG to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.SNAPTBSP to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBMADM.SNAPTBSP_PART to ${TUSER}                                                                                                           
db2 -v grant select  on table SYSIBMADM.SNAPTBSP_QUIESCER to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBMADM.SNAPTBSP_RANGE to ${TUSER}                                                                                                          
db2 -v grant select  on table SYSIBMADM.SNAPUTIL to ${TUSER}                                                                                                                
db2 -v grant select  on table SYSIBMADM.SNAPUTIL_PROGRESS to ${TUSER}                                                                                                       
db2 -v grant select  on table SYSIBMADM.TBSP_UTILIZATION to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSIBMADM.TOP_DYNAMIC_SQL to ${TUSER}                                                                                                         
db2 -v grant select  on table SYSSTAT.COLDIST to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSSTAT.COLGROUPDIST to ${TUSER}                                                                                                              
db2 -v grant select  on table SYSSTAT.COLGROUPDISTCOUNTS to ${TUSER}                                                                                                        
db2 -v grant select  on table SYSSTAT.COLGROUPS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSSTAT.COLUMNS to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSSTAT.FUNCTIONS to ${TUSER}                                                                                                                 
db2 -v grant select  on table SYSSTAT.INDEXES to ${TUSER}                                                                                                                   
db2 -v grant select  on table SYSSTAT.ROUTINES to ${TUSER}                                                                                                                  
db2 -v grant select  on table SYSSTAT.TABLES to ${TUSER}   


# For ETL
db2 -v grant use of tablespace USERSPACE1 to ${TUSER}
db2 -v grant usage on workload SYSDEFAULTUSERWORKLOAD to ${TUSER}
db2 -v grant update  on table SYSSTAT.COLDIST to ${TUSER}                                                                                                                   
db2 -v grant update  on table SYSSTAT.COLGROUPDIST to ${TUSER}                                                                                                              
db2 -v grant update  on table SYSSTAT.COLGROUPDISTCOUNTS to ${TUSER}                                                                                                        
db2 -v grant update  on table SYSSTAT.COLGROUPS to ${TUSER}                                                                                                                 
db2 -v grant update  on table SYSSTAT.COLUMNS to ${TUSER}                                                                                                                   
db2 -v grant update  on table SYSSTAT.FUNCTIONS to ${TUSER}                                                                                                                 
db2 -v grant update  on table SYSSTAT.INDEXES to ${TUSER}                                                                                                                   
db2 -v grant update  on table SYSSTAT.ROUTINES to ${TUSER}                                                                                                                  
db2 -v grant update  on table SYSSTAT.TABLES to ${TUSER}  
db2 -v grant createin on schema SQLJ to ${TUSER}  
db2 -v grant createin on schema NULLID to ${TUSER}  

FUNCTION1A=$(db2 -x "select trim(ROUTINESCHEMA)||'.'||trim(ROUTINENAME) from SYSCAT.ROUTINES where ROUTINESCHEMA in ('SQLJ','SYSFUN','SYSPROC') and ROUTINETYPE='F' ")
for tbl in ${FUNCTION1B}
do
	echo $tbl
    db2 -v GRANT EXECUTE ON FUNCTION $tbl to ${TUSER} WITH GRANT OPTION                                                                                                     
done

FUNCTION1B=$(db2 -x "select trim(ROUTINESCHEMA)||'.'||trim(ROUTINENAME) from SYSCAT.ROUTINES where ROUTINESCHEMA in ('SQLJ','SYSFUN','SYSPROC') and ROUTINETYPE='P' ")
for tbl in ${FUNCTION1B}
do
	echo $tbl
    db2 -v GRANT EXECUTE ON PROCEDURE $tbl to ${TUSER} WITH GRANT OPTION                                                                                                     
done

FUNCTION2A=$(db2 -x "select trim(ROUTINESCHEMA)||'.'||trim(ROUTINENAME) from SYSCAT.ROUTINES where ROUTINESCHEMA in ('SYSIBM','NULLID') and ROUTINETYPE='F' ")
for tbl in ${FUNCTION2A}
do
	echo $tbl
    db2 -v GRANT EXECUTE ON FUNCTION $tbl to ${TUSER}                                                                                                    
done 

FUNCTION2B=$(db2 -x "select trim(ROUTINESCHEMA)||'.'||trim(ROUTINENAME) from SYSCAT.ROUTINES where ROUTINESCHEMA in ('SYSIBM','NULLID') and ROUTINETYPE='P' ")
for tbl in ${FUNCTION2B}
do
	echo $tbl
    db2 -v GRANT EXECUTE ON PROCEDURE $tbl to ${TUSER}                                                                                                    
done    

#-- disconnect to db
db2 -v CONNECT RESET
db2 -v TERMINATE


#-- END


 