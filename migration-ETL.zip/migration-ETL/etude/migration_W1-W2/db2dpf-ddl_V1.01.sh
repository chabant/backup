SQLIN=$1

mv $SQLIN $SQLIN.init


#sed  -e  "/DISTRIBUTE BY HASH/d"  $SQLIN.init > $SQLIN
sed   -e  "1,$ s/DISTRIBUTE BY HASH(.*)//g" $SQLIN.init > $SQLIN.tmp
sed  "/DISTRIBUTE BY HASH(.*/,/.*)/c ''/g " $SQLIN.tmp > $SQLIN.tmp2
sed  -e  "1,$ s/''\/g//g"  $SQLIN.tmp > $SQLIN

#rm $SQLIN.tmp $SQLIN.tmp2
 