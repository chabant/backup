#!/bin/sh
#


DBCIBLE=${1}
USER=${2}



date

#-- validation of numbers of inputs
if [ $# -ne 2 ]
then
   echo "$?  <Database Name>=$1 <User>=$2"
   exit 1
fi

#-- connection to db
db2 -v connect to ${DBCIBLE}


TABLES=$(db2 -x "select trim(tabschema)||'.'||trim(tabname) from syscat.tables where type = 'T' and tabschema not in ('SYSIBM','SYSTOOLS') and tabname not like '%EXPLAIN_%'  ")

db2 -v revoke CONNECT on database from ${USER}

db2 -v revoke select  on table SYSCAT.TABLES from ${USER}


for tbl in ${TABLES}
do
	echo $tbl
    db2 -v revoke select on table ${tbl} from ${USER}                                                                                                             

done
db2 CONNECT RESET;
db2 TERMINATE;