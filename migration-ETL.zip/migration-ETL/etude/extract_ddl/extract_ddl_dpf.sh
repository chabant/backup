export DBNAME=${1}


set -o noglob

db2 connect to ${DBNAME}

DBPARTNUM=$(db2 -x "select  distinct dbpartitionnum from sysibmadm.dbpaths order by dbpartitionnum ")

echo $DBPARTNUM

db2 connect reset

exec pwd |read PATH


FILE_BEG=${PATH}/${DBNAME}_
FILE_END=_ts.sql

for VALUE in $DBPARTNUM
do 
	echo 'db2_all "<<+'$VALUE'< db2look -d '$DBNAME' -l -o '$FILE_BEG$VALUE$FILE_END' "'
	db2_all "<<+'$VALUE'< db2look -d '$DBNAME' -l -o '$FILE_BEG$VALUE$FILE_END' "
done

set +o noglob 





<admdevo@qs83056>[/tmp/db2-cfg/migration/export_2] 0 # ./test.sh W1DOTTD

   Database Connection Information

 Database server        = DB2/AIX64 11.1.2.2
 SQL authorization ID   = ADMDEVO
 Local database alias   = W1DOTTD

0 1 2
DB20000I  The SQL command completed successfully.
db2_all "<<+0< db2look -d W1DOTTD -l -o /tmp/db2-cfg/migration/export_2/W1DOTTD_0_ts.sql "
db2_all "<<+1< db2look -d W1DOTTD -l -o /tmp/db2-cfg/migration/export_2/W1DOTTD_1_ts.sql "
db2_all "<<+2< db2look -d W1DOTTD -l -o /tmp/db2-cfg/migration/export_2/W1DOTTD_2_ts.sql "
