SQLIN=$1

sed  -e  "1,$ s/MANAGED BY DATABASE/MANAGED BY AUTOMATIC STORAGE/g" \
     -e  "1,$ s/MANAGED BY SYSTEM/MANAGED BY AUTOMATIC STORAGE/g"   \
     -e  "/FILE '/d"  \
     -e  "1,$ s/USING (.*)//g" \
     -e  "/DBPARTITIONNUMS/d" \
     -e  "/(1);/d" 	 $SQLIN > db2_ts_auto.sql

