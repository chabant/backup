connect to xcubedev;

describe data partitions for table X show detail;
ALTER TABLE X DETACH PARTITION P1 INTO X1;
select * from X;
describe data partitions for table X show detail;
describe data partitions for table X1;
--TRUNCATE TABLE X1 REUSE STORAGE IMMEDIATE; 
--ALTER TABLE X ATTACH PARTITION P1 starting (1) ending (2) exclusive FROM X1 ;
--SET INTEGRITY FOR X ALLOW WRITE ACCESS IMMEDIATE CHECKED ;
connect reset;
