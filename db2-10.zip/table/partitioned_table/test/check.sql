connect to xcubedev;

describe data partitions for table X ;
describe data partitions for table X show detail;
select seqno,datapartitionname,ACCESS_MODE,status,lowvalue,highvalue from syscat.datapartitions where tabname = 'X' order by seqno;
describe data partitions for table Y;
describe data partitions for table Y show detail;
select seqno,datapartitionname,ACCESS_MODE,status,lowvalue,highvalue from syscat.datapartitions where tabname = 'Y' order by seqno;
connect reset;
