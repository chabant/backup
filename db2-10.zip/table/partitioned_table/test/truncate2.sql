connect to xcubedev;

describe data partitions for table X show detail;
--ALTER TABLE X DETACH PARTITION P1 INTO X1;
select * from X;
select * from X1;
describe data partitions for table X;
describe data partitions for table X1;
TRUNCATE TABLE X1 REUSE STORAGE IMMEDIATE; 
select * from X;
select * from X1;
describe data partitions for table X;
describe data partitions for table X1;
ALTER TABLE X ATTACH PARTITION P1 starting (1) ending (2) exclusive FROM X1 ;
select * from X;
select * from X1;
describe data partitions for table X;
describe data partitions for table X1;
SET INTEGRITY FOR X ALLOW WRITE ACCESS IMMEDIATE CHECKED ;
select * from X;
select * from X1;
describe data partitions for table X show detail;

connect reset;