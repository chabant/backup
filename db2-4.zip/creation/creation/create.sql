CREATE DATABASE MYDB alias MYDB on C: user tablespace managed by system using 'E:\MYDB'

CREATE DATABASE SESSION3 USING CODESET UTF-8 TERRITORY US 

CREATE DATABASE CTMCATF on /db2inst1/CTMCATF using codeset UTF-8 territory us collate using identity



CREATE DATABASE SAMPL on /home/db2inst5/db/SAMPL using codeset UTF-8 territory us collate using identity


CREATE DATABASE CQTMSR2 on /home/db2inst5/CQTMSR2 using codeset UTF-8 territory us collate using identity pagesize 32K



CREATE DATABASE SESSION3 USING CODESET UTF-8 TERRITORY US 

CREATE DATABASE WSE AUTOMATIC STORAGE YES USING CODESET UTF-8 TERRITORY US PAGESIZE 32768

create database DW on /appdata/db2inst1/db/DW using codeset UTF-8 territory en PAGESIZE 16384

	