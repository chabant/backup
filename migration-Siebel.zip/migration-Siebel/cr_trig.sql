
SET NLS_STRING_UNITS = 'SYSTEM';
SET CURRENT SCHEMA = "SIEBEL  ";
SET CURRENT PATH = "SYSIBM","SYSFUN","SYSPROC","SYSIBMADM","SIEBEL";
create trigger CTI_T_MASTER_POSTN before insert  on T_MASTER_POSTN referencing
new as n for each row begin atomic  set n.MASTER_NAME_CI = UPPER(n.MASTER_NAME); end;


