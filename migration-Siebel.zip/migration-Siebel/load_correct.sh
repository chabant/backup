#!/bin/sh
#


DBCIBLE=${1}
USER=${2}
DBSOURCE='SOURCE'


date

#-- validation of numbers of inputs
if [ $# -ne 2 ]
then
   echo "$?  <Database Name>=$1 <User>=$2 "
   exit 1
fi


#-- demande du mot de passe
echo "Entrez le mot de passe pour ${USER}: "
read PWD


#-- connection to db
db2 -v connect to ${DBCIBLE}


TABLES='SIEBEL.EIM_ACCOUNT
SIEBEL.EIM_ACTIVITY
SIEBEL.EIM_ADDR_PER
SIEBEL.EIM_AGREEMENT
SIEBEL.EIM_CAMP_CON
SIEBEL.EIM_CON_DTL
SIEBEL.EIM_CONTACT
SIEBEL.EIM_CONTACT1
SIEBEL.EIM_EMPLOYEE
SIEBEL.EIM_FN_ACCNT1
SIEBEL.EIM_FN_CONTACT1
SIEBEL.EIM_OPTY
SIEBEL.EIM_OPTY_DTL
SIEBEL.EIM_REVN
SIEBEL.EIM_REVN_DTL
SIEBEL.EIM_SRC
SIEBEL.EIM_SRC_DTL'


for db in ${DBSOURCE}
do
    for tbl in ${TABLES}
      do
        echo $tbl
        db2 -v "DECLARE C1 CURSOR DATABASE ${db} USER ${USER} USING ${PWD} FOR Select * from ${tbl} with UR"
        db2 -v "LOAD FROM C1 OF CURSOR modified by IDENTITYOVERRIDE replace INTO ${tbl} nonrecoverable";
        db2 -v "Close  C1";
      done
done
db2 CONNECT RESET;
db2 TERMINATE;
date;
