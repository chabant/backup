SET SYSIBM.NLS_STRING_UNITS = 'SYSTEM'@
SET CURRENT SCHEMA = "SIEBEL  "@
SET CURRENT PATH = "SYSIBM","SYSFUN","SYSPROC","SYSIBMADM","SIEBEL"@

create function exrate (from_cd varchar(20), to_cd varchar(20), dt timestamp)
 returns decimal(22,7)  language SQL  READS SQL DATA  external Action 
deterministic    begin atomic      declare rate double DEFAULT 1;     
declare lookup_rate decimal(22,7);      declare new_to_cd varchar(20);
     declare new_from_cd varchar(20);    IF TO_CD <> FROM_CD THEN     
SET NEW_TO_CD = To_CD;      SET NEW_FROM_CD = FROM_CD;      if FROM_CD
in ('BEF', 'DEM', 'ESP', 'FRF', 'IEP', 'ITL', 'LUF', 'NLG', 'ATS', 'PTE',
'FIM')         AND DT >= '1999-01-01-00.00.00'      THEN         SET NEW_FROM_CD
= 'EUR';         SET RATE = 1 /           CASE FROM_CD            WHEN
'BEF' THEN 40.3399            WHEN 'DEM' THEN 1.95583            WHEN 'ESP'
THEN 166.386            WHEN 'FRF' THEN 6.55957            WHEN 'IEP' THEN
.787564            WHEN 'ITL' THEN 1936.27            WHEN 'LUF' THEN 40.3399
           WHEN 'NLG' THEN 2.20371            WHEN 'ATS' THEN 13.7603 
          WHEN 'PTE' THEN 200.482            WHEN 'FIM' THEN 5.94573  
        END;       END IF;      if TO_CD in ('BEF', 'DEM', 'ESP', 'FRF',
'IEP', 'ITL', 'LUF', 'NLG', 'ATS', 'PTE', 'FIM')         AND DT >= '1999-01-01-00.00.00'
     THEN         SET NEW_TO_CD = 'EUR';         SET RATE = RATE *    
      CASE TO_CD            WHEN 'BEF' THEN 40.3399            WHEN 'DEM'
THEN 1.95583            WHEN 'ESP' THEN 166.386            WHEN 'FRF' THEN
6.55957            WHEN 'IEP' THEN .787564            WHEN 'ITL' THEN 1936.27
           WHEN 'LUF' THEN 40.3399            WHEN 'NLG' THEN 2.20371 
          WHEN 'ATS' THEN 13.7603            WHEN 'PTE' THEN 200.482  
         WHEN 'FIM' THEN 5.94573           END;       END IF;     IF NEW_TO_CD
<> NEW_FROM_CD THEN      loop1: for loop1 as        select t1.exch_rate
from s_exch_rate t1        where t1.to_curcy_cd = NEW_TO_CD         and
 t1.from_curcy_cd = NEW_FROM_CD         and  t1.exch_dt <= dt         order
by exch_dt desc      do        set LOOKUP_RATE = exch_rate;        leave
loop1;      end for;      SET RATE = RATE * LOOKUP_RATE;     END IF;  
 END IF;        if (RATE = RATE)        THEN        ELSE           SET
RATE = 1;        END IF;        return RATE;    end@