#!/bin/sh
#


DBCIBLE=${1}
USER=${2}
DBSOURCE='SOURCE'


date

#-- validation of numbers of inputs
if [ $# -ne 2 ]
then
   echo "$?  <Database Name>=$1 <User>=$2 "
   exit 1
fi


#-- demande du mot de passe
echo "Entrez le mot de passe pour ${USER}: "
read PWD


#-- connection to db
db2 -v connect to ${DBCIBLE}


TABLES=$(db2 -x "select trim(tabschema)||'.'||trim(tabname) from syscat.tables where type = 'T' and tabschema not in ('SYSIBM','SYSTOOLS') and tabname not like '%EXPLAIN_%'  ")



for db in ${DBSOURCE}
do
    for tbl in ${TABLES}
      do
        echo $tbl
        db2 -v "DECLARE C1 CURSOR DATABASE ${db} USER ${USER} USING ${PWD} FOR Select * from ${tbl} with UR"
        db2 -v "LOAD FROM C1 OF CURSOR replace INTO ${tbl} nonrecoverable";
        db2 -v "Close  C1";
      done
done
db2 CONNECT RESET;
db2 TERMINATE;
date;
