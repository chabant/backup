
export DBNAME=$1
export CMDLOADFILE=siebload.sql.err
export CMDMSGERRFILE=siebload.err

rm -f ${CMDLOADFILE}
rm -f ${CMDMSGERRFILE}

db2 connect to ${DBNAME}

for FILE in `ls *.ixf`
    do
    TABFULLNAME=${FILE%.*}
    MODIFIER=""
    TABSCHEMA=`echo $TABFULLNAME |cut -d. -f 1`
    TABNAME=`echo $TABFULLNAME |cut -d. -f 2`
    CMDIDENT="select count(1) from syscat.COLIDENTATTRIBUTES where tabschema = '${TABSCHEMA}' and tabname ='${TABNAME}' "
    cnt=`db2 -x $CMDIDENT`
    if [ "${cnt}" -ne 0 ]
       then
        echo "identite: ==> " $TABFULLNAME
        MODIFIER="modified by identityoverride"
      fi

    CMDLOAD="load from ${FILE} of ixf lobs from . ${MODIFIER} messages  $TABFULLNAME.msg replace into ${TABFULLNAME} nonrecoverable"
    db2 -v ${CMDLOAD}
    rc=$?
    if [ "${rc}" -ne 0 ]
        then
        echo "LOAD problem return code: ${rc} table: ${TABFULLNAME}"
        cat $TABFULLNAME.msg >> $CMDMSGERRFILE
        echo $CMDLOAD >> $CMDLOADFILE
        fi

done

