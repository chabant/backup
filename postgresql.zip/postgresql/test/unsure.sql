-- This file probably won't work as is. Try to run it, catch errors, and try to correct it
-- If there is an obvious improvement that can be done to its generation, please file a bug or provide a patch
 -- Only understood with 9.5+
\set ECHO errors
set client_encoding to UTF8;
set search_path TO 'db2,"$user", public';
ALTER TABLE omdrepo.omtprmld VALIDATE CONSTRAINT omtdocu0;
ALTER TABLE omdrepo.omtfamco VALIDATE CONSTRAINT omtcomm0;
ALTER TABLE omdrepo.omtfamco VALIDATE CONSTRAINT omtfaco0;
ALTER TABLE omdrepo.omtcommu VALIDATE CONSTRAINT omtcrit0;
ALTER TABLE omdrepo.omtcommu VALIDATE CONSTRAINT omtlang0;
ALTER TABLE omdrepo.omtcommu VALIDATE CONSTRAINT omtmocp0;
ALTER TABLE omdrepo.omtcommu VALIDATE CONSTRAINT omtscac0;
ALTER TABLE omdrepo.omtcommu VALIDATE CONSTRAINT omtstco0;
ALTER TABLE omdrepo.omtcommu VALIDATE CONSTRAINT omtsysa0;
ALTER TABLE omdrepo.omtcommu VALIDATE CONSTRAINT omttyno0;
ALTER TABLE omdrepo.omtfodoc VALIDATE CONSTRAINT omtdocu0;
ALTER TABLE omdrepo.omtfodoc VALIDATE CONSTRAINT omtform0;
ALTER TABLE omdrepo.omtcanco VALIDATE CONSTRAINT omtcana0;
ALTER TABLE omdrepo.omtcanco VALIDATE CONSTRAINT omtcomm0;
ALTER TABLE omdrepo.omtdocco VALIDATE CONSTRAINT omtcomm0;
ALTER TABLE omdrepo.omtdocco VALIDATE CONSTRAINT omtdocu0;
ALTER TABLE omdrepo.omtdocco VALIDATE CONSTRAINT omtform0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtclas0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtcoim0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtcrit0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtcyvi0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtdcnov;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtfado0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtimpr0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtlang0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtmodo0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtscac0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtstdo0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omtsysa0;
ALTER TABLE omdrepo.omtdocum VALIDATE CONSTRAINT omttyim0;
ALTER TABLE omdrepo.omtopcom VALIDATE CONSTRAINT omtcomm0;
ALTER TABLE omdrepo.omtopcom VALIDATE CONSTRAINT omtoptc0;
ALTER TABLE omdrepo.omtopcom VALIDATE CONSTRAINT omtoptd0;
ALTER TABLE omdrepo.omtopcom VALIDATE CONSTRAINT omttyde0;
ALTER TABLE omdrepo.omtfocan VALIDATE CONSTRAINT omtcana0;
ALTER TABLE omdrepo.omtfocan VALIDATE CONSTRAINT omtform0;
ALTER TABLE omdrepo.omtimppa VALIDATE CONSTRAINT omtdocu0;
ALTER TABLE omdrepo.omtimppa VALIDATE CONSTRAINT omtrefp0;
ALTER TABLE omdrepo.omtimppa VALIDATE CONSTRAINT omttyin0;
ALTER TABLE omdrepo.omtcouen VALIDATE CONSTRAINT omtcana0;
ALTER TABLE omdrepo.omtopdoc VALIDATE CONSTRAINT omtdocu0;
ALTER TABLE omdrepo.omtopdoc VALIDATE CONSTRAINT omtoptc0;
ALTER TABLE omdrepo.omtopdoc VALIDATE CONSTRAINT omtoptd0;
ALTER TABLE omdrepo.omtopdoc VALIDATE CONSTRAINT omttyde0;
-- Under this point, are functions. There is NO WAY they will work
-- They are only here so that they crash at creation and you notice them and correct them by hand
-- Under this point, are triggers. There is NO WAY they will work
-- They are only here so that they crash at creation and you notice them and correct them by hand
