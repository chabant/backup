set client_encoding to UTF8;
CREATE SCHEMA omdrepo;


CREATE TABLE omdrepo.omtcriti (
	cd_cri_doc SMALLINT NOT NULL,
	lb_cri_doc CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtfadoc (
	cd_fam_doc CHAR(2) NOT NULL,
	lb_fam_doc CHAR(50) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtsrvex (
	cd_agence_exc CHAR(6) NOT NULL,
	no_srv_agence_exc CHAR(8) NOT NULL DEFAULT '',
	adr_srv_agence_exc VARCHAR(256) NOT NULL DEFAULT '',
	tmp_agence_exc TIMESTAMP NOT NULL DEFAULT '0001-01-01 00:00:00.000000',
	nom_constraint_exc varchar(32768) NOT NULL DEFAULT '');

COMMENT ON TABLE omdrepo.omtsrvex IS 'Table d''exception non modélisée par l''ADD pour les rejets du chargement quotidien de la table OMTSRVAG    ';

CREATE TABLE omdrepo.omtimprv (
	cd_impr_recto CHAR(1) NOT NULL,
	lb_impr_recto CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtprmld (
	cd_mdoc_pdl CHAR(30) NOT NULL,
	nu_ver_config_doc_pdl CHAR(4) NOT NULL,
	nu_ord_pdl SMALLINT NOT NULL,
	cd_pdl CHAR(18) NOT NULL DEFAULT '',
	lb_pdl CHAR(30) NOT NULL DEFAULT '',
	cd_fmt_pdl CHAR(10) NOT NULL DEFAULT '',
	top_ctrl_pdl CHAR(1) NOT NULL DEFAULT '',
	cd_typ_ctrl_pdl CHAR(15) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtclasd (
	cd_cl_secu_don SMALLINT NOT NULL,
	lb_cl_secu_don CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtfamco (
	cd_fam_com_famco CHAR(4) NOT NULL,
	cd_mcom_famco CHAR(30) NOT NULL,
	nu_ver_config_com_famco CHAR(20) NOT NULL);


CREATE TABLE omdrepo.omtrefen (
	cd_ref_env CHAR(20) NOT NULL,
	lb_ref_env CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtmodoc (
	cd_mdoc CHAR(30) NOT NULL);


CREATE TABLE omdrepo.omttyno (
	cd_typ_not SMALLINT NOT NULL,
	lb_typ_not CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtcommu (
	cd_mcom_com CHAR(30) NOT NULL,
	nu_ver_config_com CHAR(20) NOT NULL,
	lb_com CHAR(75) NOT NULL DEFAULT '',
	cd_sect_act_com CHAR(3) NOT NULL DEFAULT '',
	cd_ref_env_com CHAR(20) NOT NULL DEFAULT '',
	cd_rang_pos_com CHAR(20) NOT NULL DEFAULT '',
	cd_str_ref_cnt_com CHAR(20) NOT NULL DEFAULT '',
	cd_statu_com_com CHAR(3) NOT NULL DEFAULT '',
	cd_lang_com CHAR(3) NOT NULL DEFAULT '',
	cd_systeme_com CHAR(2) NOT NULL DEFAULT '',
	cd_typ_dest_com CHAR(5) NOT NULL DEFAULT '',
	cd_cri_doc_com SMALLINT NOT NULL DEFAULT 0,
	cd_cout_pos_com CHAR(5) NOT NULL DEFAULT '',
	cd_taille_env_com CHAR(5) NOT NULL DEFAULT '',
	dt_deb_ver_com DATE NOT NULL DEFAULT current_date,
	nu_th_com CHAR(20) NOT NULL DEFAULT '',
	nu_ver_com CHAR(3) NOT NULL DEFAULT '',
	top_interactif_com CHAR(1) NOT NULL DEFAULT '',
	top_demat_com CHAR(1) NOT NULL DEFAULT '',
	nu_batch_th_com CHAR(20) NOT NULL DEFAULT '',
	nom_emet_sms_com CHAR(40) NOT NULL DEFAULT '',
	lb_email_a_com CHAR(100) NOT NULL DEFAULT '',
	lb_email_cc_com CHAR(100) NOT NULL DEFAULT '',
	lb_email_cci_com CHAR(100) NOT NULL DEFAULT '',
	lb_email_obj_com CHAR(60) NOT NULL DEFAULT '',
	cd_colis_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p1_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p2_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p3_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p4_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p5_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p6_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p7_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p8_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p9_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p10_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p11_pli_com CHAR(20) NOT NULL DEFAULT '',
	cd_ins_p12_pli_com CHAR(20) NOT NULL DEFAULT '',
	top_rgi_let_com CHAR(1) NOT NULL DEFAULT '',
	cd_emet_recomd_com CHAR(3) NOT NULL DEFAULT '',
	top_rerout_com CHAR(1) NOT NULL DEFAULT '',
	cd_ref_rerout1_com CHAR(8) NOT NULL DEFAULT '',
	cd_ref_rerout2_com CHAR(8) NOT NULL DEFAULT '',
	cd_per_max_ret_com CHAR(20) NOT NULL DEFAULT '',
	cd_adr_typ_com CHAR(2) NOT NULL DEFAULT '',
	cd_alliag_prem_com CHAR(32) NOT NULL DEFAULT '',
	lb_fil_imp_loc_com CHAR(30) NOT NULL DEFAULT '',
	lb_bac_a_utili_com CHAR(20) NOT NULL DEFAULT '',
	cd_typ_not_com SMALLINT NOT NULL DEFAULT 0,
	top_imp_cen_gl_com CHAR(1),
	nu_ordre_com INTEGER NOT NULL DEFAULT 99);


CREATE TABLE omdrepo.omtrefco (
	cd_str_ref_cnt CHAR(20) NOT NULL,
	lb_str_ref_cnt CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtcoupo (
	cd_cout_pos CHAR(5) NOT NULL,
	lb_cout_pos CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtsrvag (
	cd_agence CHAR(6) NOT NULL,
	no_srv_agence CHAR(8) NOT NULL DEFAULT '',
	adr_srv_agence VARCHAR(256) NOT NULL DEFAULT '');

COMMENT ON TABLE omdrepo.omtsrvag IS 'SERVEUR PAR AGENCE';

CREATE TABLE omdrepo.omtscact (
	cd_sect_act CHAR(3) NOT NULL,
	lb_sect_act CHAR(50) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtfodoc (
	cd_mdoc_doc_fod CHAR(30) NOT NULL,
	nu_ver_config_doc_fod CHAR(4) NOT NULL,
	cd_fmt_doc_fod CHAR(3) NOT NULL,
	nom_doc_fod CHAR(20) NOT NULL DEFAULT '');

COMMENT ON COLUMN omdrepo.omtfodoc.nom_doc_fod IS 'Nom du modèle de document.';

CREATE TABLE omdrepo.omttydes (
	cd_typ_dest CHAR(5) NOT NULL,
	cd_opt_dis_typ_dest SMALLINT NOT NULL DEFAULT 0,
	cd_opt_consu_typ_dest SMALLINT NOT NULL DEFAULT 0,
	lb_typ_dest CHAR(20) NOT NULL DEFAULT '',
	cd_ged_typ_dest CHAR(4) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtlang (
	cd_lang CHAR(3) NOT NULL,
	lb_lang CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtcanco (
	cd_canal_caco CHAR(10) NOT NULL,
	cd_mcom_caco CHAR(30) NOT NULL,
	nu_ver_config_com_caco CHAR(20) NOT NULL,
	nom_com_caco CHAR(20) NOT NULL DEFAULT '');

COMMENT ON COLUMN omdrepo.omtcanco.nom_com_caco IS 'nom du canal de communication';

CREATE TABLE omdrepo.omtdocco (
	cd_mdoc_dco CHAR(30) NOT NULL,
	nu_ver_config_doc_dco CHAR(4) NOT NULL,
	cd_mcom_dco CHAR(30) NOT NULL,
	nu_ver_config_com_dco CHAR(20) NOT NULL,
	nom_com_dco CHAR(20) NOT NULL,
	nom_doc_dco CHAR(20) NOT NULL,
	top_obl_dco CHAR(1) NOT NULL DEFAULT '',
	cd_ord_list_dco CHAR(2) NOT NULL DEFAULT '',
	cd_fmt_doc_dco CHAR(3) NOT NULL DEFAULT '');

COMMENT ON COLUMN omdrepo.omtdocco.nom_doc_dco IS 'Nom du modèle de document.';
COMMENT ON COLUMN omdrepo.omtdocco.nom_com_dco IS 'Nom du modèle de communication.';

CREATE TABLE omdrepo.omtranpo (
	cd_rang_pos CHAR(20) NOT NULL,
	lb_rang_pos CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtfacom (
	cd_fam_com CHAR(4) NOT NULL,
	lb_fam_com CHAR(30) NOT NULL DEFAULT '',
	lb_distres_cre_com CHAR(44),
	lb_distres_val_com CHAR(44));


CREATE TABLE omdrepo.omtdocum (
	cd_mdoc_doc CHAR(30) NOT NULL,
	nu_ver_config_doc CHAR(4) NOT NULL,
	lb_doc CHAR(75) NOT NULL DEFAULT '',
	cd_lang_doc CHAR(3) NOT NULL DEFAULT '',
	cd_sect_act_doc CHAR(3) NOT NULL DEFAULT '',
	cd_fam_doc_doc CHAR(2) NOT NULL DEFAULT '',
	cd_coul_impr_doc CHAR(2),
	cd_statu_doc_doc CHAR(3) NOT NULL DEFAULT '',
	cd_cri_doc_doc SMALLINT NOT NULL DEFAULT 0,
	cd_systeme_doc CHAR(2) NOT NULL DEFAULT '',
	cd_sens_flx_doc CHAR(1) NOT NULL DEFAULT '',
	cd_typ_impr_doc CHAR(1),
	cd_impr_recto_doc CHAR(1),
	cd_cl_secu_don_doc SMALLINT NOT NULL DEFAULT 0,
	cd_clas_cyvie_doc CHAR(2),
	cd_typ_dest_doc CHAR(5),
	dt_deb_ver_doc DATE NOT NULL DEFAULT current_date,
	nu_ver_flx_th_doc CHAR(20) NOT NULL DEFAULT '',
	nu_template_th_doc CHAR(20) NOT NULL DEFAULT '',
	nu_ver_th_doc CHAR(3) NOT NULL DEFAULT '',
	nu_pgm_predcou_doc CHAR(2) NOT NULL DEFAULT '',
	nu_idx_ecm_arc_doc CHAR(40) NOT NULL DEFAULT '',
	lb_mention_doc CHAR(30) NOT NULL DEFAULT '',
	top_original_doc CHAR(1) NOT NULL DEFAULT '',
	cd_typ_doc CHAR(20) NOT NULL DEFAULT '',
	top_interactif_doc CHAR(1) NOT NULL DEFAULT '',
	cd_index_met_1_doc CHAR(20) NOT NULL DEFAULT '',
	cd_index_met_2_doc CHAR(20) NOT NULL DEFAULT '',
	cd_index_met_3_doc CHAR(20) NOT NULL DEFAULT '',
	cd_index_met_4_doc CHAR(20) NOT NULL DEFAULT '',
	cd_index_met_5_doc CHAR(20) NOT NULL DEFAULT '',
	cd_index_met_6_doc CHAR(20) NOT NULL DEFAULT '',
	cd_index_met_7_doc CHAR(20) NOT NULL DEFAULT '',
	cd_index_met_8_doc CHAR(20) NOT NULL DEFAULT '',
	lb_ged_doc CHAR(40) NOT NULL DEFAULT '',
	lb_internet_doc CHAR(75) NOT NULL DEFAULT '',
	nb_page_doc SMALLINT NOT NULL DEFAULT 0,
	nom_pj_email_doc CHAR(30) NOT NULL DEFAULT '',
	lb_obj_email_doc CHAR(120) NOT NULL DEFAULT '',
	cd_depot_doc CHAR(1) NOT NULL DEFAULT 'S',
	cd_typ_doc_doc CHAR(3),
	cd_sgn_elec_doc CHAR(7),
	cd_opt_envoi_doc CHAR(7),
	top_alim_chat_doc CHAR(1));

COMMENT ON COLUMN omdrepo.omtdocum.cd_depot_doc IS 'permet de distinguer les documents à envoyer dans la GED Novaxel.';

CREATE TABLE omdrepo.omtopcom (
	cd_mcom_opcom CHAR(30) NOT NULL,
	nu_ver_config_com_opcom CHAR(20) NOT NULL,
	cd_opt_dis_opcom SMALLINT NOT NULL,
	cd_opt_consu_opcom SMALLINT NOT NULL,
	cd_typ_dest_opcom CHAR(5) NOT NULL);


CREATE TABLE omdrepo.omtfocan (
	cd_fmt_doc_foc CHAR(3) NOT NULL,
	cd_canal_foc CHAR(10) NOT NULL);


CREATE TABLE omdrepo.omtrefpa (
	cd_ref_pap CHAR(20) NOT NULL,
	poids_unite_pap DECIMAL(13,5) NOT NULL DEFAULT 0,
	mt_prix_unite_pap DECIMAL(13,5) NOT NULL DEFAULT 0,
	lb_ref_pap CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtstdoc (
	cd_statu_doc CHAR(3) NOT NULL,
	lb_statu_doc CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omttyimp (
	cd_typ_impr CHAR(1) NOT NULL,
	lb_typ_impr CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omttyint (
	cd_typ_intlo CHAR(2) NOT NULL,
	lb_typ_intlo CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtmocpm (
	cd_mcom CHAR(30) NOT NULL);


CREATE TABLE omdrepo.omtsysap (
	cd_systeme CHAR(2) NOT NULL,
	lb_systeme CHAR(20) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtforma (
	cd_fmt_doc CHAR(3) NOT NULL,
	lb_fmt_doc CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omttaien (
	cd_taille_env CHAR(5) NOT NULL,
	lb_taille_env CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtimppa (
	cd_mdoc_dip CHAR(30) NOT NULL,
	nu_ver_config_doc_dip CHAR(4) NOT NULL,
	cd_ref_pap_dip CHAR(20) NOT NULL,
	cd_typ_intlo_dip CHAR(2) NOT NULL,
	nom_doc_dip CHAR(20) NOT NULL DEFAULT '',
	top_defaut_dip CHAR(1) NOT NULL DEFAULT '');

COMMENT ON COLUMN omdrepo.omtimppa.nom_doc_dip IS 'Nom du modèle de document.';

CREATE TABLE omdrepo.omtcyvie (
	cd_clas_cyvie CHAR(2) NOT NULL,
	lb_clas_cyvie CHAR(50) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtcouen (
	cd_canal_cout_envoi CHAR(10) NOT NULL,
	nu_cout_envoi SMALLINT NOT NULL DEFAULT 0,
	cd_mcom_cout_envoi CHAR(30) NOT NULL DEFAULT '',
	nom_com_cout_envoi CHAR(20) NOT NULL DEFAULT '',
	nu_ver_config_com_cout_envoi CHAR(20) NOT NULL DEFAULT '',
	mt_cout_envoi DECIMAL(13,5) DEFAULT 0);

COMMENT ON COLUMN omdrepo.omtcouen.nom_com_cout_envoi IS 'Nom du modèle de communication.';

CREATE TABLE omdrepo.omtopdoc (
	cd_mdoc_opdoc CHAR(30) NOT NULL,
	nu_ver_config_doc_opdoc CHAR(4) NOT NULL,
	cd_opt_consu_opdoc SMALLINT NOT NULL,
	cd_opt_dis_opdoc SMALLINT NOT NULL,
	cd_typ_dest_opdoc CHAR(5) NOT NULL);


CREATE TABLE omdrepo.omtstcom (
	cd_statu_com CHAR(3) NOT NULL,
	lb_statu_com CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtdcnov (
	cd_typ_doc_nov CHAR(3) NOT NULL,
	lb_typ_doc_nov CHAR(75) NOT NULL DEFAULT '');

COMMENT ON TABLE omdrepo.omtdcnov IS 'TYPE DE DOCUMENT NOVAXEL';

CREATE TABLE omdrepo.omtcoimp (
	cd_coul_impr CHAR(2) NOT NULL,
	lb_coul_impr CHAR(30));


CREATE TABLE omdrepo.omtoptds (
	cd_opt_dis SMALLINT NOT NULL,
	lb_opt_dis CHAR(50) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtoptcn (
	cd_opt_consu SMALLINT NOT NULL,
	lb_opt_consu CHAR(30) NOT NULL DEFAULT '');


CREATE TABLE omdrepo.omtcanal (
	cd_canal CHAR(10) NOT NULL,
	lb_canal CHAR(20) NOT NULL DEFAULT '',
	cd_ged_canal CHAR(4) NOT NULL DEFAULT '',
	nu_ordre_canal INTEGER NOT NULL DEFAULT 99);


