require 'spec_helper'

shared_examples 'oss_to_xpack_upgrade::init' do |vars|
end
