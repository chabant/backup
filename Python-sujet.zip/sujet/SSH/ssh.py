from subprocess import PIPE, Popen

cmd = 'uname -a'
stream = Popen(['ssh', 'chabant@qs83056.agf.fr' , cmd],stdin=PIPE, stdout=PIPE)
stream.stdin.write(b'AMBAZAC7\n')
#stream.stdin.flush()
rsp = stream.stdout.read().decode('utf-8')
print(rsp)


===========================================================
# s4.py
#!/usr/bin/python
import os

os.system('ssh bogotob1@bogotobogo.com python < uname.py >> mylog.txt 2>&1')
os.system('ssh bogotob1@bogotobogo.com sh < uptime.sh >> mylog.txt 2>&1')
os.system('ssh bogotob1@bogotobogo.com perl < hello.pl >> mylog.txt 2>&1')